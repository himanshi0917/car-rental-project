<?php

ini_set("display_errors",1);
session_start();
include 'config.php';
if(!isset($_SESSION['users']['id'])){
  // header("location: http://localhost/irentacar/index.php");
  
}
else{
  $id=$_SESSION['users']['id'];
}



if(isset($_FILES["file"])){
    $image_name = $_FILES['file']['name'];   
    $targetDir = 'uploaded_images/';
    $id=$_SESSION['users']['id'];
     $targetFile = $targetDir . basename($image_name); 
     move_uploaded_file($_FILES['file']['tmp_name'], $targetFile);

     $query = "UPDATE login_detail SET  file='$targetFile'  WHERE Id=$id";


 $consuc= mysqli_query($conn,$query);

 if(!$consuc){
    die("not submited :". mysqli_error($conn));
   }
else{
    echo"successfuly submitted";
};


};

if(isset($_POST['carid'])){
  $cardetail=$_POST['carid'];
  $query="SELECT * FROM vehical_host where Id=$cardetail";
  $vechdata= mysqli_query($conn,$query);

  $fetchvech=mysqli_fetch_assoc($vechdata);

// if(mysqli_num_rows( $vechdata)>0){
// while( $fetchvech=mysqli_fetch_assoc( $vechdata)){
// echo "<pre>";
// print_r($fetchvech);
// echo "</pre>";
// }
// }
// else{
//   echo "result not found";
// }
//  mysqli_error($conn);
//  die; 

?>

<script>
  $(document).find('#date_picker').daterangepicker({
    timePicker: true,
   starthour:<?php echo  $fetchvech['available_from']?>,
   endhour:<?php echo $fetchvech['available_till']?>,
   locale: { format: "YYYY/MM/DD HH:mm A"},
  })
  </script>
<div class="single-car">
  <a id="back-btn" ><img src="images/prev-arrow.png"  class="mb-5"></a> 
      
      <div class="w-full flex items-center justify-center mb-5">
      
          <img class="inline-block mr-1.5 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto w-44 flex-1" src="images/line.png" />
      
          <h2 class="font-bold font-roboto text-lg text-headingColor uppercase text-center"><?php echo $fetchvech['car_brand'].$fetchvech['car_model'];?></h2>
      
          <img class="inline-block ml-1.5 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto w-44 flex-1" src="images/line.png" />
      
      </div>
      
      <div class="w-full">
      
          <img src="<?php echo $fetchvech['car_img'];?>" class="w-full">
      
      </div>
      
      <div class="mt-6 flex gap-3 justify-between items-center">
      
       <div class="flex-1">
      
        <img src="images/seater.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $fetchvech['seat_cap'];?></label>
      
      </div>
      
      <div class="flex-1">
      
        <img src="images/fuel-pump-diesel.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $fetchvech['fuel_type'];?></label>
      
      </div>
      
      <div class="flex-1">
      
        <img src="images/automatic-icon.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $fetchvech['transm_type'];?></label>
      
      </div>
      
      <div class="flex-1">
      
       

          <label class="text-headingColor font-roboto font-medium text-base">Km Driven</label><br />
  
            <input name="driven"  type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor" value="<?php echo $fetchvech['driven'];?>" placeholder="15000km" />
  
   
      
      </div>
      
      <div class="flex-1">
      
      <a   class="cursor-pointer bg-darkblue py-4 rounded-full block text-center"><button id="edit-btn" class="font-roboto font-semibold text-base text-white">Edit</button></a>
      
      </div>
      
      </div>
      
      <form id="update_form">
      
          <div class="mt-10 border border-borderColor px-6 py-10 rounded-[15px]">
      
          <h3 class="text-headingColor font-roboto font-bold text-xl text-center mb-3">Select date range</h3>
      
          <div class="flex gap-10">
      
            <div class="block w-full text-center">
      
              <!-- <input type="date" class="border mt-2 w-full font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/calender-icon.svg')] bg-no-repeat bg-[96%_center] mb-2 focus:border-darkblue focus:outline-none" required
      
               placeholder="mm/dd/yyyy" /> -->
      
               <div class="grid-cols-1 place-items-center mb-10">
<input type="text" name="date-time" id="date_picker" value="<?php echo $fetchvech['available_from']." ".$fetchvech['available_till'] ?>" class="focus:outline-none focus:border-darkblue border mt-2 w-full font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/calender-icon.svg')] bg-no-repeat bg-[98%_center]" />
</div>

      
      </div>
      
   
      
               <!-- <input type="date" class="border mt-2 w-full font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/calender-icon.svg')] bg-no-repeat bg-[96%_center] mb-2 focus:border-darkblue focus:outline-none" 
      
               placeholder="dd/mm/yyyy" /> -->
      
     
      
          </div>
      
          <input type="hidden" name="car_id" value="<?= $fetchvech['Id']?>">
      
          <input type="button" name="update_data" id="update_data" class="text-center mx-auto cursor-pointer mt-12 block font-roboto text-lg bg-darkblue rounded-full text-white font-[800] py-4 px-20 uppercase tracking-widest" value="Update" />
      </form>

    </div>

      <div class="container mx-auto " id="click-edit" style="display:none">
   
<div class="bg-darkblue rounded-tl-[15px] rounded-tr-[15px] mt-13 w-full flex items-center justify-center p-5">
  <div class="close">
     <p class="cls-p">close</p>
  </div>

    <img class="inline-block mr-4 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto" src="images/white-rectangle.png" />

    <h2 class="font-bold font-roboto text-xl text-white uppercase text-center">Edit your vehicle deatail</h2>

    <img class="inline-block ml-4 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto" src="images/white-rectangle.png" />

</div>

<form  class="border-t-0 border border-borderColor rounded-bl-[15px] rounded-br-[15px] p-16 mb-20" id="save_data" style="background-color:white;">

  <div class="grid grid-cols-2 mx-12 gap-5">

    <div class="w-full">

      <label class="text-headingColor font-roboto font-medium text-base">Car Brand</label><br />

        <select name="car_brand" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor">

            <option>Car Brand</option>

            <option <?php echo $fetchvech['car_brand'] == "Audi" ? 'selected': '';?>>  Audi</option>

            <option <?php echo $fetchvech['car_brand'] == "BMW" ? 'selected': '';?> >BMW</option>

            <option <?php echo $fetchvech['car_brand'] == "Mercedes" ? 'selected': '';?> >Mercedes</option>

            <option <?php echo $fetchvech['car_brand'] == "Ferrari" ? 'selected': '';?> >Ferrari</option>

        </select>

    </div>

    <div class="w-full">

      <label class="text-headingColor font-roboto font-medium text-base">Car Model</label><br />

      


        <input  name="car_model" type="text"  value="<?php echo $fetchvech['car_model'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor" placeholder="Car Model" />

    </div>

    <!-- <div class="w-full">

        <label class="text-headingColor font-roboto font-medium text-base">Car Varient</label><br />

          <input type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor" placeholder="Car Varient" />

      </div> -->


     <div class="w-full">

        <label class="text-headingColor font-roboto font-medium text-base">Km Driven</label><br />

          <input name="driven"  type="text"  value="<?php echo $fetchvech['driven'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor" placeholder="15000km" />

      </div>

     <!--   <div class="w-full">

        <label class="text-headingColor font-roboto font-medium text-base">Ownership</label><br />

          <select class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor">

              <option selected>Ist owner</option>

              <option>Ist owner</option>

              <option>Ist owner</option>

              <option>Ist owner</option>

              <option>Ist owner</option>

          </select> -->

      

      <div class="w-full">

        <h4 class="text-headingColor font-roboto font-medium text-base w-full mb-3">Fuel Type</h4>

        <label for="type" class="inline-flex mr-4">

          <input name="fuel_type" type="radio" class="checked mr-2 py-4 px-2.5" id="Diesel" value="Diesel" <?php echo trim($fetchvech['fuel_type']) == "Diesel" ? 'checked': '';?> > 

          <div class="text-paragraphColor text-base font-roboto font-normal">Diesel</div>

          </label>

          <label for="petrol" class="inline-flex mr-4" >

          <input  name="fuel_type" type="radio" class="mr-2 py-4 px-2.5" id="petrol" value="petrol" <?php echo trim($fetchvech['fuel_type'])=="petrol" ? 'checked': '';?> > 
          

          <div class="text-paragraphColor text-base font-roboto font-normal">Petrol

          </div>

          </label>

          <label for="electric" class="inline-flex">

            <input name="fuel_type" type="radio" class="mr-2 py-4 px-2.5" id="electric" value="electric" <?php echo trim($fetchvech['fuel_type']) == "electric" ? 'checked': '';?>> 

            <div class="text-paragraphColor text-base font-roboto font-normal">Electric</div>

        </label>

      </div>

      <div class="w-full">

        <h4 class="text-headingColor font-roboto font-medium text-base w-full mb-3">Transmission Type</h4>

        <label for="automatic" class="inline-flex mr-4">

          <input name="transm_type" type="radio" class="checked mr-2 py-4 px-2.5" id="automatic" value="Automatic" <?php echo $fetchvech['transm_type'] == "Automatic" ? 'checked': '';?>> 

          <div class="text-paragraphColor text-base font-roboto font-normal">Automatic</div>

          </label>

          <label for="manual" class="inline-flex mr-4">

          <input name="transm_type" type="radio" class="mr-2 py-4 px-2.5" id="manual" value="Manual" <?php echo $fetchvech['transm_type'] == "Manual" ? 'checked': '';?>> 

          <div class="text-paragraphColor text-base font-roboto font-normal">Manual</div>

          </label>

      </div>

    </div>


    <div class="bg-lightColor mt-10 rounded-[15px] p-6 w-full">

<div class="grid-cols-1 gap-4 mb-2">


<label for="dropzone-file" class="mx-auto cursor-pointer flex w-full max-w-lg flex-col items-center rounded-[30px] border border-borderColor bg-white p-6 text-center">

<p class="mb-5 text-paragraphColor font-base font-medium font-roboto">change car image </p>

<img src="" class="mb-4">

<span> </span>

<input id="img_file" accept=".png,.jpeg" type="file"  name="car_img" >


</div>



</div>

<div class="bg-lightColor mt-10 rounded-[15px] p-6 w-full">
<div class="grid-cols-2 p-5">

<h4 class="text-headingColor font-roboto font-medium text-base w-full mb-3">Seating Capacity</h4>

<label for="4 seater" class="inline-flex mr-4">

<input name="seat_type" type="radio" class="checked mr-2 py-4 px-2.5"  value="4 seater" <?php echo trim($fetchvech['seat_cap']) == "4 seater" ? 'checked': '';?> > 

<div class="text-paragraphColor text-base font-roboto font-normal">4 seater</div>

</label>

<label for="5 seater" class="inline-flex mr-4" >

<input  name="seat_type" type="radio" class="mr-2 py-4 px-2.5"  value="5 seater" <?php echo trim($fetchvech['seat_cap']) == "5 seater" ? 'checked': '';?>> 

<div class="text-paragraphColor text-base font-roboto font-normal">5 seater

</div>

</label>

<label for="6 seater" class="inline-flex">

<input name="seat_type" type="radio" class="mr-2 py-4 px-2.5"  value="6 seater" <?php echo trim($fetchvech['seat_cap']) == "6 seater" ? 'checked': '';?>> 

<div class="text-paragraphColor text-base font-roboto font-normal">6 seater</div>

</label>

<div class="grid-cols-2">

        <label class="text-headingColor font-roboto font-medium text-base">Price</label><br />

          <input name="price"  type="text" value="<?php echo $fetchvech['price'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor" placeholder="$1120" />
</div>

   
</div>
</div>
<input type="hidden" name="vech_id" value="<?= $fetchvech['Id']?>">

<input type="button" name="submit" id="save-btn" class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white py-4 px-20 uppercase" value="SAVE" />
</form>

</div>


<?php
exit();
}
?>


<?php


if(isset($_POST['vech_id'])){
  $car_brand = $_POST["car_brand"];
  $car_model = $_POST["car_model"];
  $driven = $_POST["driven"];
  $fuel_type = $_POST["fuel_type"];
  $seat_type = $_POST["seat_type"];
  $price = $_POST["price"];
  $transm_type = $_POST["transm_type"];
  $img_path=$_FILES['car_img'];
  
  $id=$_POST["vech_id"];
  if($_FILES['car_img']['name'] !=""){

    echo"<pre>";
print_r($_FILES);
    echo"</pre>";
    echo"<pre>";
print_r($_POST);
    echo"</pre>";
    $file_name = $_FILES['car_img']['name'];   
      $targetDir = 'uploaded_images/';
       $targetFile = $targetDir . basename($file_name); 
       move_uploaded_file($_FILES['car_img']['tmp_name'], $targetFile);
  $path2=$targetFile;



$query="UPDATE vehical_host Set car_brand='$car_brand',car_model='$car_model',seat_cap=' $seat_type',price='$price',driven='$driven',fuel_type=' $fuel_type',transm_type='$transm_type' , car_img='$path2' where Id=$id";}
else{
  $query="UPDATE vehical_host Set car_brand='$car_brand',car_model='$car_model',seat_cap=' $seat_type',price='$price',driven='$driven',fuel_type=' $fuel_type',transm_type='$transm_type' where Id=$id";
}
$consuc= mysqli_query($conn,$query);






  }


  
if(isset($_POST['car_id'])){
  $id=$_POST['car_id'];
 


  $date=$_POST['date-time'];

  $datetime= explode("-",$date);
  $strtfromdate=str_replace("/","-",trim($datetime[0]));
  $endtilldate=str_replace("/","-",trim($datetime[1]));


  $query="UPDATE vehical_host SET available_from='$strtfromdate',available_till=' $endtilldate' where Id=$id";
  $vechdata= mysqli_query($conn,$query);



}
?>
<?php
if(isset($_POST['segment']) || isset($_POST['fuel_type']) || isset($_POST['filter']) || isset($_POST['transm_type']) || isset($_POST['seat_cap'])|| isset($_POST['city']) || isset($_POST['date']) || isset($_POST['search'])  ){

  $segment=isset($_POST['segment'])? $_POST['segment']: "";
  $fuel_type=isset($_POST['fuel_type'])? $_POST['fuel_type']: "";
  $transm_type=isset($_POST['transm_type'])? $_POST['transm_type']: "";
  $seat_cap=isset($_POST['seat_cap'])? $_POST['seat_cap']: "";
  $search=isset($_POST['search'])? $_POST['search']: "";
$filter=isset($_POST['filter'])? $_POST['filter']: "";
$city=isset($_POST['city'])? $_POST['city']: "";
$date=isset($_POST['date'])? $_POST['date']: "";
$st_where=false;

$datetime= explode("-",$date);
  $strtdate=str_replace("/","-",trim($datetime[0]));
  $enddate=str_replace("/","-",trim($datetime[1]));
$st_combine= $search!="" || $city!="" || $strtdate!=$enddate || $segment!="" ||$fuel_type!="" || $transm_type!="" ||  $seat_cap!="" ;
// echo"<pre>";
// print_r($datetime);
// echo"</pre>";
switch($filter){
  case"HightoLow":
    $orderby="price DESC";
    break;
    case"LowtoHigh":
      $orderby="price ASC";
      break;
      case"LatestProucts":
        $orderby="Id DESC";
        break;
        default:
        $orderby="Id ASC";
}

$sql_z = "SELECT * FROM vehical_host ";
$count=count($_POST);
$i=0;
$exec=0;
foreach($_POST as $key=>$value ){ 
 $i++; 
 if(!$st_where && $st_combine){
  $sql_z.= "  WHERE  user_id!=$id AND  ";
  $st_where=true;
}
//  echo count($_POST)."-". $i."\n" ;
if($key!=="search" && $key!=="filter" && $key!=="date" && $key!=="city" ){
  $exec++;

  $sql_z.= $i>1 && $exec>1?"   AND    ":'';
  $sql_z.= " $key LIKE '%$value%'";

}
  elseif($value!=="" && $key=="search"){
    $exec++;

    $sql_z.= $i>1 && $exec>1 ?"   AND   ":'';
  $sql_z.=" car_brand LIKE '%$value%' OR car_model LIKE '%$value%' ";
}
elseif($value!=="" && $key=="city"){
  $exec++;

  $sql_z.= $i>1 && $exec>1?"   AND   ":'';
  $sql_z.=" city LIKE '%$value%' ";
}
elseif($key=="date"){
  if($strtdate!=$enddate){
    $exec++;
    $sql_z.= $i>1 && $exec>1 ?"   AND   ":'';
  $sql_z.="available_from >='$strtdate' AND available_till <='$enddate'";
  }
}
    }
 $sql_z.= ($exec==0 ? " WHERE user_id!=$id AND approval=true":'')."  ORDER BY $orderby";
  // echo $sql_z;
  // echo "<pre>";
  // print_r($_POST);
  // echo "</pre>";
$filter= mysqli_query($conn,$sql_z);
// if(mysqli_num_rows($filter)>0){
// while($data_for_rent=mysqli_fetch_assoc($filter)){
// echo "<pre>";
// print_r($data_for_rent);
// echo "</pre>";
// }
// }
// else{
//   echo "result not found";
// }
//  mysqli_error($conn);
//  die; 
if(mysqli_num_rows($filter)>0){ 
?>
  <?php 
  while($data_for_rent=mysqli_fetch_assoc($filter)){
  ?>
  <div class="rounded-[25px] w-full border border-borderColor car
  -list">

  <a href="Booking-details.php?vech_id=<?php echo $data_for_rent['Id']?>">  <img src="<?= $data_for_rent['car_img']?>" class="rounded-tl-[25px] rounded-tr-[25px]" /></a>

    <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">

      <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">

      <?= $data_for_rent['seat_cap']  ?>

      </div>

      <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">

       <?= $data_for_rent['fuel_type']  ?>

      </div>

      <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">

      <?= $data_for_rent['transm_type']  ?>

      </div>

    </div>

    <div class="py-8 mx-auto block text-center">

      <h3 class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">

      <?= $data_for_rent['car_brand'].$data_for_rent['car_model'] ?>

      </h3>

      <p class="font-roboto font-normal text-base text-center text-paragraphColor">

      <?= "Start from ". $data_for_rent['price']."/per day" ?> 

      </p>

      <div class="mt-7 mb-1">

        <a href="Booking-details.php?vech_id=<?php echo  $data_for_rent['Id']?>" class="cursor-pointer">

          <button class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">

            Rent now

          </button></a>

      </div>

    </div>

  </div>
<?php
}
}

else{
  echo"<p>  RESULT NOT FOUND </p>";
}
}
?>


<?php


if(isset($_POST['pdata'])){
 $id=$_POST['pdata'];
// echo $id;

  $query_to_get="SELECT l.drv_lcen_no, l.mobile_no, l.full_name,l.email_id,v.car_brand,v.car_model,b.avl_from,b.avl_till FROM login_detail l JOIN car_booking b ON l.Id=b.user_id JOIN vehical_host v ON v.Id=b.vech_id  WHERE b.booking_id=$id ";


$exec_to_get= mysqli_query($conn,$query_to_get);
// echo "<pre>";
// print_r($exec_to_get);
// echo "</pre>";
$getdata=mysqli_fetch_assoc($exec_to_get); 
// echo "<pre>";
// print_r($getdata);
// echo "</pre>";

?>

<div  class="details" id="tab-hosting">

<div class="cursor-pointer w-full">

     <a id="Prvs-btn" ><img src="images/prev-arrow.png"></a>

</div>

<div class="w-full bg-lightColor rounded-[15px] p-8 pb-10 mt-10">

  <div class="w-full pr-5">

 <h4 class="font-roboto font-bold font-base text-headingColor text-center">Time period</h4>

  </div>

 <div class="w-full">

<div class="flex justify-between mb-2">

<img src="images/blue-loca-icon.svg">

<span class="border border-borderColor w-full h-0 my-2"></span>

<img src="images/red-loca-icon.svg">



    </div>

    <div class="flex justify-between">

   <span class="font-roboto font-bold font-base text-darkblue inline-block"><?php  echo date("Y-m-d",strtotime($getdata['avl_from']))?></span>

  <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">    <?php echo date("Y-m-d",strtotime($getdata['avl_till']))?></span> </div>

  <div class="flex justify-between">

  <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50"><?php echo date("H:i:s",strtotime($getdata['avl_from'])) ?></span>

   <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50"><?php echo date("H:i:s",strtotime($getdata['avl_till'])) ?></span></div>


</div>

</div>



<form class="border borderColor py-10 px-8 rounded-[15px] mt-10">

  <div class="flex flex-col">

    <div class="w-full flex items-center justify-center mb-5">

      <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

      <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Personal Details</h2>

      <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

  </div>

  <div class="flex">

  <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Name </label>

  <input type="email" value="<?php echo $getdata['full_name']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

</div>

<div class="flex">

  <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Contact</label>

  <input type="tel" value="<?php echo $getdata['mobile_no']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

</div>

<div class="flex">

<label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Driving license No</label>

<input type="tel" value="<?php echo $getdata['drv_lcen_no']?>" class="text-paragraphColor font-roboto font-normal text-base w-3/5"> 

</div>

</div>



</form>





<form class="border borderColor py-10 px-8 rounded-[15px] mt-10">

<div class="flex flex-col">

  <div class="w-full flex items-center justify-center mb-5">

    <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

    <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Rental's Details</h2>

    <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

</div>

<div class="flex">

<label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Car Brand Name</label>

<input type="email" value="<?php echo $getdata['car_brand']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

</div>

<div class="flex">

<label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Model</label>

<input type="tel" value="<?php echo $getdata['car_model']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

</div>

<div class="flex">

<label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Driving license No</label>

<input type="tel" value="<?php echo $getdata['drv_lcen_no']?>" class="text-paragraphColor font-roboto font-normal text-base w-3/5"> 

</div>

</div>



</form>



</div>
<?php
}
?>

<?php
if(isset($_POST['cancel'])){
  $cancel=$_POST['cancel'];

 $query="UPDATE car_booking SET status='cancelled' where booking_id=$cancel";

 $update_carbook=mysqli_query($conn,$query);
 
// echo $update_carbook;
// exit();

}

?>

<?php
 if(isset($_POST['user_id'])){
 $id= $_POST['user_id'];
 $rating=$_POST['rating'];
 $review=$_POST['review'];

 $insert_rvw="INSERT INTO users_review (user_id,rating,review) VALUES ('$id','$rating','$review')";
 $exe_rvw=mysqli_query($conn,$insert_rvw);


 }

?>


<?php
if(isset($_POST['log_uname']) && isset($_POST['log_pass']) ){
  $log_uname=$_POST['log_uname'];
  $log_pass=$_POST['log_pass'];

  // echo "<pre>";
  // print_r($_POST);
  // echo "</pre>";

  $query= "SELECT  * FROM login_detail WHERE user_name='$log_uname' ";

$consuc= mysqli_query($conn,$query);
$login=mysqli_num_rows($consuc);
if($login){
    $email_pas=mysqli_fetch_assoc($consuc);
 


$db_pas= $email_pas['password'];

// echo "<pre>";
// print_r($db_pas);
// echo "</pre>";
$res=['message'=>" ", 'status'=>" "];
if(password_verify($log_pass,$db_pas)){
 
    $_SESSION['users']=array('id'=>$email_pas['Id'],
                              'full_name'=>$email_pas['full_name'],
                                'city'=>$email_pas['city'],
                                   'u_name'=>$email_pas['user_name']);

  

                                   $res['message']="logged in successully";
                                   $res['status']="success";
    
}
else 
{

  
    $res['message']="incorrect password";
    $res['status']="failed";
}
}

else{
  $res['message']="invalid email";
  $res['status']="failed";

}
echo json_encode($res);
exit();
}
?>