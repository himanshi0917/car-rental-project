<?php
date_default_timezone_set('Asia/Kolkata');



?>



<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap"
        rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/flowbite@1.4.0/dist/flowbite.js"></script>
     <link rel="stylesheet" href="https://unpkg.com/@themesberg/flowbite@1.2.0/dist/flowbite.min.css"/> 
    <link rel="stylesheet" href="css/tailwind.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.3.js"
        integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="js/logscript.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<link rel="stylesheet" href="css/style.css">




    <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/smoothness/jquery-ui.css"><link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.css" /><script src="//code.jquery.com/ui/1.13.0/jquery-ui.min.js"></script><script type="text/javascript" src="//cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script> --><!-- <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.css" /><script type="text/javascript" src="//cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script> --><!-- <link rel="stylesheet" href="css/pickmeup.css" type="text/css" /><link rel="stylesheet" media="screen" type="text/css" href="demo/demo.css" /><script type="text/javascript" src="js/pickmeup.js"></script><script type="text/javascript" src="demo/demo.js"></script><link rel="stylesheet" href="css/pickmeup.css"><script src="js/pickmeup.js"></script> -->
    <script>    tailwind.config = { theme: { container: { screens: { DEFAULT: "100%", xs: "320px", sm: "640px", md: "768px", lg: "1024px", xl: "1170px", }, }, extend: { colors: { darkblue: "#17ADC4", headingColor: "#242D35", paragraphColor: "#414548", lightColor: "#EAF3F3", }, backgroundOpacity: { 85: ".85", }, fontFamily: { roboto: ["Roboto"], }, outlineOffset: { 15: "15px", }, }, }, };  </script>
</head>

<body> 
  
  
    <div class="login-page">
        <div class="form">
        <span class="close">&times;</span>
          <form  action="http://localhost/irentacar/index.php" class="register-form" method="post">
            <input name="fname" type="text" placeholder="firstname"/>
            <input name="lname" type="text" placeholder="lastname"/>
            <input name="password" type="password" placeholder="password"/>
            <input  name="email" type="text" placeholder="email address"/>
            <button type="submit" name="submitto_reg" >create</button>
            <p class="message">Already registered? <a id="sign" href="javascript:void(0)">Sign In</a></p>
          </form>
          <form class="login-form">
            <input class="login_usrname" name="username" type="text" placeholder="username"/>
            <div class="login_pass-eye">
            <input class="login_pass"  name="userpassword" type="password" placeholder="password"  />
            <!-- <span id="toggle_pwd" class="fa fa-fw fa-eye field_icon" style="margin-left: -30px; cursor: pointer;"></span> -->
            <i class="far fa-eye" id="togglePassword" style="margin-left: -70px; cursor: pointer;"></i>
          </div>
            <button type="button" name="submitto_login" class="click-to-login" >login</button>
            <div class="error"></div>
            <p class="message">Not registered? <a id="createac" href="javascript:void(0)">Create an account</a></p>
          </form>
        </div>
      </div>
   
    
    
    
    
    
    
    
    <!-------------------- Header-------------------------------->
    <div class="bg-black flex opacity-85 p-2">
        <div class="container mx-auto flex items-center justify-between"> <a href="index.php"><img
                    src="images/logo.svg" /></a>
            <div class="flex items-center"> 
              
            <?php   if(!isset($_SESSION['users']['id'])){
    
    ?> <a href="javascript:void(0)" id="log" class="cursor-pointer">
            <button
                class="font-roboto text-base border-2 border-white rounded-full text-white font-semibold py-4 px-8 uppercase mx-4 bg-darkblue">login / register</button> </a>
              <?php
              }
              ?>
              
               <a href="Filters.php" class="cursor-pointer"><button
                        class="font-roboto text-base border-2 border-white rounded-full text-white font-semibold py-4 px-16 uppercase mx-4">Rent
                        a Car</button></a> <a href="Become-a-host.php" class="cursor-pointer"><button
                        class="font-roboto text-lg bg-white rounded-full text-headingColor font-medium py-4 px-10 uppercase mr-4">Become
                        A Host </button></a>
                         
<img class="block mr-3 cursor-pointer" id="multiLevelDropdownButton"  src="images/humburger.svg" data-dropdown-toggle="dropdown" > 
<div id="dropdown" class="z-10 hidden bg-white rounded-lg shadow w-80">
    <ul class="py-0 text-sm text-gray-700 divide divide-y dark:text-gray-200" aria-labelledby="multiLevelDropdownButton">
      <li>
        <a href="Profile.php" class="inline-flex gap-2 items-center px-6 py-4 group hover:text-white hover:bg-darkblue rounded-tl-lg rounded-tr-lg w-full">
            <img src="images/profile-icon.svg"  class="block group-hover:hidden">
            <img src="images/profile-white-icon.svg" class="hidden group-hover:block">Profile</a>
      </li>
      <li>
        <a href="#" class="inline-flex gap-2 items-center px-6 py-4 hover:text-white group hover:bg-darkblue w-full">
            <img src="images/inbox-icon.svg" class="block group-hover:hidden">
            <img src="images/inbox-white-icon.svg" class="hidden group-hover:block">inbox</a>
      </li>
      <li>                
        <a href="Become-a-host.php" class="inline-flex gap-2 items-center px-6 py-4 hover:text-white group hover:bg-darkblue w-full">
            <img src="images/host-icon.svg" class="block group-hover:hidden">
            <img src="images/host-white-icon.svg" class="hidden group-hover:block">  Become a Host</a>
      </li>
      
      <li>
        <a href="#" class="inline-flex gap-2 items-center px-6 py-4 hover:text-white group hover:bg-darkblue w-full" onclick="changeAtiveTab(event,'tab-bookings')">
            <img src="images/trips-icon.svg" class="block group-hover:hidden">
            <img src="images/trips-white-icon.svg" class="hidden group-hover:block">My Trips</a>
      </li>
      
      <?php  if(isset($_SESSION['users']['id'])){

      ?>
      <li>
        <a href="logout.php" class="inline-flex gap-2 items-center px-6 py-4 hover:bg-[#CFE7EB] rounded-bl-lg rounded-br-lg w-full">
            <img src="images/logout.svg">Logout</a>
      </li> 
<?php 
}
?>
     
      <!-- <li>
        <button id="doubleDropdownButton" data-dropdown-toggle="doubleDropdown" data-dropdown-placement="right-start" type="button" class="flex items-center justify-between w-full px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Dropdown<svg aria-hidden="true" class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg></button>
          <div id="doubleDropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
            <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="doubleDropdownButton">
              <li>
                <a href="index.html" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Overview</a>
              </li>
              <li>
                <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">My downloads</a>
              </li>
              <li>
                <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Billing</a>
              </li>
              <li>
                <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Rewards</a>
              </li>
            </ul>
        </div>
      </li> -->
    
    </ul>
</div>
               <a href="Profile.php"  onclick="changeAtiveTab(event,'tab-profile')"> 
              <img class="block" src="images/user.svg"></a>


           
           
            </div>
        </div>
    </div>