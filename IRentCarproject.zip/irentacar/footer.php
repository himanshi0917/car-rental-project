 <!--------------------------- Footer ---------------------------------->
 <div class="bg-black">
        <div class="container mx-auto">
            <div class="flex py-20 justify-between">
                <div class="w-[35%] mr-4"> <a href="index.php"><img src="images/logo.svg" class="mb-4"></a>
                    <p class="font-normal font-roboto text-base text-white mb-5"> Lorem ipsum dolor sit amet,
                        consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        Ut enim ad minim veniam ut aliquip ex ea commodo consequat. <a href="javascript:void(0)"
                            class="font-roboto font-semibold text-base underline block mt-5">Read More</a> </p>
                </div>
                <div class="w-[15%]">
                    <h3 class="font-bold font-roboto text-[22px] text-white mb-5">Quick Links</h3> <a
                        href="javascript:void(0)" class="font-roboto font-normal text-white text-base block pb-4">About
                        Us</a> <a href="javascript:void(0)"
                        class="font-roboto font-normal text-white text-base block pb-4">Services</a> <a
                        href="javascript:void(0)"
                        class="font-roboto font-normal text-white text-base block pb-4">Testimonials</a> <a
                        href="javascript:void(0)" class="font-roboto font-normal text-white text-base block">Contact
                        Us</a> </p>
                </div>
                <div class="w-[15%]">
                    <h3 class="font-bold font-roboto text-[22px] text-white mb-5">Support</h3> <a
                        href="javascript:void(0)" class="font-roboto font-normal text-white text-base block pb-4">Help
                        center</a> <a href="javascript:void(0)"
                        class="font-roboto font-normal text-white text-base block pb-4">Ask a question</a> <a
                        href="javascript:void(0)"
                        class="font-roboto font-normal text-white text-base block pb-4">Privacy policy</a> <a
                        href="javascript:void(0)" class="font-roboto font-normal text-white text-base block">Terms &
                        conditions</a>
                </div>
                <div class="w-[20%]">
                    <h3 class="font-bold font-roboto text-[22px] text-white mb-5">Contact Us</h3> <a
                        href="javascript:void(0)" class="font-roboto font-normal text-white text-base block pb-4"><span
                            class="font-bold block">Email:</span>info@rentcar*****.com</a> <a href="javascript:void(0)"
                        class="font-roboto font-normal text-white text-base block pb-4"><span
                            class="font-bold block">Call Us:</span>0790 ***** 0336</a> <a href="javascript:void(0)"
                        class="font-roboto font-normal text-white text-base block"><span
                            class="font-bold block">Location:</span> 1425 Lorem Lane, Miami Ny – 20140, USA</a> </p>
                </div>
            </div>
            <p class="font-normal font-roboto text-base text-white mb-20"> <span class="font-bold">Disclaimer:
                </span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
                ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
                qui officia deserunt mollit anim id est laborum. </p>
            <div class="border border-[#C8C8C8] opacity-30"> </div>
            <div class="flex justify-between py-4 items-center">
                <div class="flex">
                    <p class="text-white">Copyright © 2023 I Rent A Car. All Rights Reserved.</p>
                </div>
                <div class="inline-flex py-2 justify-end space-x-3"> <a href="javascript:void(0)" target="_blank"><img
                            src="images/fb.svg"></a> <a href="javascript:void(0)" target="_blank"><img
                            src="images/insta.svg"></a> <a href="javascript:void(0)" target="_blank"><img
                            src="images/twitter.svg"></a> <a href="javascript:void(0)" target="_blank"><img
                            src="images/youtube.svg"></a> </div>
            </div>
        </div>
    </div>
    <!---------------------------End of Footer ----------------------------><!---------------------------Login Popup ----------------------------------->
    <div class="login_popup hidden fixed inset-0 z-10 h-48 m-auto mx-auto bg-[#054049]/80 h-screen">
        <div class="flex w-2/5 px-5 m-auto mx-auto fixed inset-0 z-20 h-min m-auto mx-auto">
            <div class="flex w-1/2 bg-lightColor p-8 justify-center items-center rounded-tl-[25px] rounded-bl-[25px]">
                <img src="images/popup-image.png"></div>
            <div class="flex w-1/2 bg-white flex flex-col justify-center p-8 rounded-tr-[25px] rounded-br-[25px]">
                <h3 class="font-roboto text-headingColor font-bold text-3xl mb-5 text-center">Login</h3>
                <form><input type="tel" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" placeholder="Enter your phone" required
                        class="mb-2 w-full font-normal font-roboto text-base paragraphColor/50 border border-borderColor rounded-[30px] py-3 px-2"><input
                        type="submit"
                        class="cursor-pointer mt-2 font-roboto text-lg bg-darkblue rounded-full text-white font-[800] w-full py-3 px-20 uppercase tracking-widest"
                        value="Login" /><a
                        class="text-base font-normal text-[#666666] text-center font-roboto my-4 block"
                        href="javascript:void(0)">Don’t have an account?</a><button type="button"
                        class="cursor-pointer font-roboto text-lg bg-white rounded-full text-headingColor border-2 font-[800] w-full py-3 px-20 uppercase tracking-widest border border-[#17ADC4]">Signup</button>
                    <div class="flex mt-5 mx-auto justify-center items-center"> <a href="javascript:void(0)"
                            class="inline-flex mr-4" target="_blank"><img src="images/logos_google-icon.svg"></a> <a
                            href="javascript:void(0)" class="inline-flex " target="_blank"><img
                                src="images/logos_facebook.svg"></a></div>
                </form>
            </div>
        </div>
    </div><!---------------------------End of Login Popup ---------------------------->
    <script>    // Burger menus    document.addEventListener('DOMContentLoaded', function () {      // open      const burger = document.querySelectorAll('.navbar-burger');      const menu = document.querySelectorAll('.navbar-menu');      if (burger.length && menu.length) {        for (var i = 0; i < burger.length; i++) {          burger[i].addEventListener('click', function () {            for (var j = 0; j < menu.length; j++) {              menu[j].classList.toggle('hidden');            }          });        }      }      // close      const close = document.querySelectorAll('.navbar-close');      const backdrop = document.querySelectorAll('.navbar-backdrop');      if (close.length) {        for (var i = 0; i < close.length; i++) {          close[i].addEventListener('click', function () {            for (var j = 0; j < menu.length; j++) {              menu[j].classList.toggle('hidden');            }          });        }      }      if (backdrop.length) {        for (var i = 0; i < backdrop.length; i++) {          backdrop[i].addEventListener('click', function () {            for (var j = 0; j < menu.length; j++) {              menu[j].classList.toggle('hidden');            }          });        }      }    });  </script>
    <script>  $(document).ready(function () { $(".login-btn").click(function () { $(".login_popup").toggle(); }); });</script>
    <script>

        // Burger menus
    
        document.addEventListener('DOMContentLoaded', function () {
    
          // open
    
          const burger = document.querySelectorAll('.navbar-burger');
    
          const menu = document.querySelectorAll('.navbar-menu');
    
    
    
          if (burger.length && menu.length) {
    
            for (var i = 0; i < burger.length; i++) {
    
              burger[i].addEventListener('click', function () {
    
                for (var j = 0; j < menu.length; j++) {
    
                  menu[j].classList.toggle('hidden');
    
                }
    
              });
    
            }
    
          }
    
    
    
          // close
    
          const close = document.querySelectorAll('.navbar-close');
    
          const backdrop = document.querySelectorAll('.navbar-backdrop');
    
    
    
          if (close.length) {
    
            for (var i = 0; i < close.length; i++) {
    
              close[i].addEventListener('click', function () {
    
                for (var j = 0; j < menu.length; j++) {
    
                  menu[j].classList.toggle('hidden');
    
                }
    
              });
    
            }
    
          }
    
    
    
          if (backdrop.length) {
    
            for (var i = 0; i < backdrop.length; i++) {
    
              backdrop[i].addEventListener('click', function () {
    
                for (var j = 0; j < menu.length; j++) {
    
                  menu[j].classList.toggle('hidden');
    
                }
    
              });
    
            }
    
          }
    
        });
    
      </script>
    
    <script>
    function changeAtiveTab(event, tabID) {
  let element = event.target;
  while (element.nodeName !== "A") {
    element = element.parentNode;
  }
  ulElement = element.parentNode.parentNode;
  aElements = ulElement.querySelectorAll("li > a");
  tabContents = document
    .getElementById("tabs-id")
    .querySelectorAll(".tab-content > div");
  for (let i = 0; i < aElements.length; i++) {
    aElements[i].classList.remove("text-white");
    aElements[i].classList.remove("bg-pink-600");
    aElements[i].classList.add("text-white");
    aElements[i].classList.add("bg-darkblue");
    tabContents[i].classList.add("hidden");
    tabContents[i].classList.remove("block");
  }
  element.classList.remove("text-pink-600");
  element.classList.remove("bg-darkblue");
  element.classList.add("text-white");
  element.classList.add("bg-black");
  document.getElementById(tabID).classList.remove("hidden");
  document.getElementById(tabID).classList.add("block");
}

$(function () {
  $('input[name="datetimes"],[name="DateFrom"]').daterangepicker({
    timePicker: true,
    startDate:  <?php if(isset($strtfromdate)){
     echo "'".$strtfromdate."'";
}
     else{
      echo 'moment().startOf("hour")';
        }?>,
       endDate:<?php if(isset($endtilldate)){
       echo  "'".$endtilldate."'";
    }
   else{
    echo 'moment().startOf("hour")';
  }?>,
    locale: { format: "YYYY/MM/DD HH:mm A"},
    
  });

});// addEventListener('DOMContentLoaded', function () {// 	pickmeup('.single', {// 		flat : true// 	});// 	pickmeup('.multiple', {// 		flat : true,// 		mode : 'multiple'// 	});// 	pickmeup('.range', {// 		flat : true,// 		mode : 'range'// 	});// 	var plus_5_days = new Date;// 	plus_5_days.setDate(plus_5_days.getDate() + 5);// 	pickmeup('.three-calendars', {// 		flat      : true,// 		date      : [// 			new Date,// 			plus_5_days// 		],// 		mode      : 'range',// 		calendars : 3// 	});// 	pickmeup('input', {// 		position       : 'right',// 		hide_on_select : true// 	});// });  </script>
    <!-- <script>    $(document).ready(function() {      $('#daterange').daterangepicker({        opens: 'left'      }, function(start, end, label) {        console.log("A new date range was selected: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));      });    });  </script> -->
</body>

</php>