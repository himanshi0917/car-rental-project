<?php 
      
include('../config/database.php');

       $cat= !empty($_GET['cat'])?$_GET['cat']:'';
       $subcat = !empty($_GET['subcat'])?$_GET['subcat']:'';
      
          if($cat=='website-setting' && $subcat=='add-website-menu'){
          
          include('../scripts/multilevel-script.php');
          
        }

        if(!empty($cat) && !empty($subcat)){

            
            $sub=explode('-', $subcat);
if($sub[0]=='add')
{
           $val=[];
          foreach ($sub as $key => $value) {
            if($value==$sub[0])
            {
             continue;
            }
            $val[]=$value;
            
         }
        
      include("../".$cat."/".implode('-',$val).".php");   
 }else{
  include("../".$cat."/".$subcat.".php");
 }
 

          
        }
        
        // else{
        //     echo "<h1 class='text-success text-center'>Welcome To Admin Panel</h1>";
        // }
        ?>


        	  <?php

	 if(isset($_POST['dataid'])) {
		$id=$_POST['dataid'];
		$value=$_POST['value'];
// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
$update_query="UPDATE vehical_host SET approval=$value WHERE Id=$id";
$execu_update_que=mysqli_query($conn,$update_query);

echo  $execu_update_que;
exit;
	 }
	 
	 ?>



<?php
if(isset($_POST['view'])){
  $id=$_POST['view'];
// echo"<pre>";
// print_r($_POST);
// echo"</pre>";

$sqllog="SELECT * FROM login_detail WHERE Id=$id";
$execu_sqllog=mysqli_query($conn,$sqllog);
$fetch_book=mysqli_fetch_assoc($execu_sqllog);





?>


   
   <div class="mt-13 w-full flex items-center justify-center p-5">
	
	   <h2 class="text-center">User's login detail</h2>
  <div class="close-log">
		<p class="cls-btn">close</p>
	 </div>
    </div>
   
   <form  class=" p-16 mb-20" id="save_data" style="background-color:white;">
   
	
   
	   <div class="w-full">
   <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">User ID</label><br />
   
		 <input   type="text"  value="<?php echo $fetch_book['Id'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-0.5 " />
   </div>
	   
   
   <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">User name</label><br />
<input   type="text"  value="<?php echo $fetch_book['user_name'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-2.5 " />
   
	   </div>
</div>

		<div class="w-full">
		<div class="w-half">
		   <label class="text-headingColor font-roboto font-medium text-base label">password</label><br />
   
			 <input  type="text"  value="<?php echo $fetch_book['password'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
   
		 </div>
		 <div class="w-half">
   
		 <label class="text-headingColor font-roboto font-medium text-base label">email id</label><br />
   
   <input   type="text"  value="<?php echo $fetch_book['email_id'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
</div>
 </div>
   
		 <div class="w-full">
		 <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">Mobile number</label><br />
   
   <input   type="text"  value="<?php echo $fetch_book['mobile_no'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "  />
		 </div>
		 <div class="w-half">
   <label class="text-headingColor font-roboto font-medium text-base label">drving licence no</label><br />
   <input name="driven"  type="text"  value="<?php echo $fetch_book['drv_lcen_no'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "/>
</div>
</div>
   <div class="w-full">
	<div class="w-half">
		   <label class="text-headingColor font-roboto font-medium text-base label">Gender</label><br />
   
			 <input   type="text" value="<?php echo $fetch_book['gender'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "/>
   </div>

   <div class="w-half">
   
   <label class="text-headingColor font-roboto font-medium text-base label ">City</label><br />

	 <input  type="text" value="<?php echo $fetch_book['city'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
</div>
</div>
   </div>
   </form>
   
   <?php
}
?>
 
  




   <?php
if(isset($_POST['view_veh'])){
   $veh_id=$_POST['view_veh'];
ini_set("display_errors",1);


 $sqlveh= "SELECT * FROM vehical_host WHERE Id=$veh_id";
 $execu_sqlveh=mysqli_query($conn,$sqlveh);
 $fetch_book=mysqli_fetch_assoc($execu_sqlveh);
 
//  echo"<pre>";
//  print_r($_POST);
//  echo"</pre>";
 
//  die;

?>

<div class="mt-13 w-full flex items-center justify-center p-5">
	
   <h2 class="text-center">User's login detail</h2>
<div class="close-vehical">
   <p class="cls-btn-forveh">close</p>
 </div>
 </div>

<form  class=" p-16 mb-20" id="save_data" style="background-color:white;">



   <div class="w-full">
<div class="w-half">
    <label class="text-headingColor font-roboto font-medium text-base label">User ID</label><br />

 <input   type="text"  value="<?php echo $fetch_book['Id'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-0.5 " />
   </div>
	   
   
   <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">Full name</label><br />
<input   type="text"  value="<?php echo $fetch_book['full_name'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-2.5 " />
   
	   </div>
</div>

		<div class="w-full">
		<div class="w-half">
		   <label class="text-headingColor font-roboto font-medium text-base label">Car Brand</label><br />
   
			 <input  type="text"  value="<?php echo $fetch_book['car_brand'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
   
		 </div>
		 <div class="w-half">
   
		 <label class="text-headingColor font-roboto font-medium text-base label">Car Model</label><br />
   
   <input   type="text"  value="<?php echo $fetch_book['car_model'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
</div>
 </div>
   
		 <div class="w-full">
		 <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">Price</label><br />
   
   <input   type="text"  value="<?php echo $fetch_book['price'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "  />
		 </div>
		 <div class="w-half">
   <label class="text-headingColor font-roboto font-medium text-base label">City </label><br />
   <input   type="text"  value="<?php echo $fetch_book['city'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "/>
</div>
</div>
   <div class="w-full">
	<div class="w-half">
		   <label class="text-headingColor font-roboto font-medium text-base label">fuel type</label><br />
   
			 <input   type="text" value="<?php echo $fetch_book['fuel_type'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "/>
   </div>

   <div class="w-half">
   
   <label class="text-headingColor font-roboto font-medium text-base label ">Transmission type</label><br />

	 <input  type="text" value="<?php echo $fetch_book['transm_type'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
</div>
</div>
<div class="w-full">
	<div class="w-half">
		   <label class="text-headingColor font-roboto font-medium text-base label">Vehc number</label><br />
   
			 <input   type="text" value="<?php echo $fetch_book['vech_num'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "/>
   </div>

   <div class="w-half">
   
   <label class="text-headingColor font-roboto font-medium text-base label ">segment</label><br />

	 <input  type="text" value="<?php echo $fetch_book['segment'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
</div>
</div>
   </div>
   </form>
   
   <?php
}
?>
 
<?php
 if(isset($_POST['prvw_booking'])){
   $car_id=$_POST['prvw_booking'];

//  echo"<pre>";
//  print_r($_POST);
//  echo"</pre>";

 $sqlbook= "SELECT l.full_name,v.car_brand,v.car_model,c.booking_id,c.avl_from,c.avl_till,c.status FROM login_detail l JOIN car_booking c ON l.Id=c.user_id JOIN vehical_host v ON v.Id=c.vech_id WHERE c.booking_id=$car_id";
 $execu_sqlbook=mysqli_query($conn,$sqlbook);
 $fetch_book=mysqli_fetch_assoc($execu_sqlbook);
 

 
 

?>

<div class="mt-13 w-full flex items-center justify-center p-5">
	
   <h2 class="text-center">car booking detail</h2>
<div class="close-booking">
   <p class="cls-btn-forveh">close</p>
 </div>
 </div>

<form  class=" p-16 mb-20" id="save_data" style="background-color:white;">



   <div class="w-full">
<div class="w-half">
    <label class="text-headingColor font-roboto font-medium text-base label">User ID</label><br />

 <input   type="text"  value="<?php echo $fetch_book['booking_id'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-0.5 " />
   </div>
	   
   
   <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">Car Brand/Model</label><br />
<input   type="text"  value="<?php echo $fetch_book['car_brand']."  ".$fetch_book['car_model'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-2.5 " />
   
	   </div>
</div>

		<div class="w-full">
		<div class="w-half">
		   <label class="text-headingColor font-roboto font-medium text-base label">  User name</label><br />
   
			 <input  type="text"  value="<?php echo $fetch_book['full_name'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
   
		 </div>
		 <div class="w-half">
   
		 <label class="text-headingColor font-roboto font-medium text-base label">Booked From</label><br />
   
   <input   type="text"  value="<?php echo $fetch_book['avl_from'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 " />
</div>
 </div>
   
		 <div class="w-full">
		 <div class="w-half">
		 <label class="text-headingColor font-roboto font-medium text-base label">Booked Till</label><br />
   
   <input   type="text"  value="<?php echo $fetch_book['avl_till'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "  />
		 </div>
		 <div class="w-half">
   <label class="text-headingColor font-roboto font-medium text-base label">booking status</label><br />
   <input   type="text"  value="<?php echo $fetch_book['status'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 "/>
</div>
</div>
   
   </div>
   </form>
   
   <?php
}
?>
  


  <?php
if(isset($_POST['rvw_id'])){
   $review_id=$_POST['rvw_id'];
   $rating=$_POST['rating'];
   $reviews=$_POST['reviews'];


$update_rvw="UPDATE users_review SET rating='$rating' ,review='$reviews' WHERE review_id=$review_id";
$exec_update_rvw=mysqli_query($conn,$update_rvw);

}
  ?>

  <?php

if(isset($_POST['view_review'])){
   $review_id=$_POST['view_review'];

//  echo"<pre>";
//  print_r($_POST);
//  echo"</pre>";

 $sqlreview= "SELECT r.review_id ,r.user_id,r.rating,r.review,l.full_name,l.file FROM login_detail l JOIN users_review r  ON  r.user_id=l.Id WHERE r.review_id=$review_id";
 $execu_sqlreview=mysqli_query($conn,$sqlreview);
 $fetch_review=mysqli_fetch_assoc($execu_sqlreview);
 

 
 


?>
<div class="mt-13 w-full flex items-center justify-center p-5">
	
   <h2 class="text-center">car booking detail</h2>
<div class="close-review">
   <p class="cls-btn-forview">close</p>
 </div>
 </div>


<form   class=" p-16 mb-20" id="update_data">

<!-- <input type="hidden" data-id="<?php echo $fetch_review['review_id'];?>"> -->

   <div class="w-full">
<div class="w-half">
    <label class="text-headingColor font-roboto font-medium text-base label">REVIEW ID</label><br />

 <input   type="text"  value="<?php echo $fetch_review['review_id'];?>" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-1 px-0.5 rvw_id" />
   </div>
	   
   
   <div class="w-half">
      <label class="text-headingColor font-roboto font-medium text-base label">  RATING</label><br />
   
      <input  type="text"  value="<?php echo $fetch_review['rating'];?>"class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-1 px-2.5 rating" />

	   </div>
</div>

		<div class="w-full">
		 <div class="w-half">
   
		 <label class="text-headingColor font-roboto font-medium text-base label">REVIEW</label><br />
   <textarea  class="textarea_size mb-4  reviews"><?php echo $fetch_review['review'];?></textarea>
   
</div>
 </div>
   
	
<input type="hidden" name="review_id" value="<?= $fetch_review['review_id']?>">

<input type="button" name="submit" id="upd-btn" class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white  uppercase" value="UPDATE"/>

   </form>
   </div>
   
<?php
}
?>