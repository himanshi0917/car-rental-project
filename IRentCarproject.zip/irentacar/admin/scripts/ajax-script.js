

// ============= admin rol ==============//

$(document).on('click', '.adminRole', function(e){
       
       var el=$(this);
       var name=$(this).attr('name');
       var id=$(this).attr('rel');
        $.ajax({
        method:"GET",
        url: "scripts/backend-script.php",
        data:{tableName:name,id:id,role:'admin'},
    
        success: function(data){

          switch(data)
          {
            case 'fas fa-user-alt-slash iconRole':
            el.attr('class', 'text-secondary adminRole');
            break;
            case 'fas fa-user-alt iconRole':
            el.attr('class', 'text-success adminRole');
            break;
          }
       
       el.find('.iconRole').attr('class', data);


    }});
});

//======= Insert data through admin form==========// 

$(document).on('submit','#adminForm',function(e){
        e.preventDefault();
       var name=$(this).attr('name');
        $.ajax({
        method:"POST",
        url: "scripts/backend-script.php?name="+name,
        data:$(this).serialize(),
         beforeSend:function(){
         $('button[type="submit"]').attr('disabled','disabled').text('Saving..');
       },
        success: function(data){
       
        $('#adminForm').find('input').val('')
        $('#adminForm').find('textarea').val('');
        $('button[type="submit"]').removeAttr('disabled').text('Save');
       
       $('#alertBox').html(data).fadeIn();

    }});
       
});


//========= update data through update form============ //


$(document).on('submit','#updateForm',function(e){
        e.preventDefault();
       var formData = new FormData(this);
       var name=$(this).attr('name');
       var id= $(this).attr('rel');
        $.ajax({
        method:"POST",
        url: "scripts/backend-script.php?name="+name+"&id="+id,
        data:formData,
        cache:false,
        contentType: false,
        processData: false,
         beforeSend:function(){
         $('button[type="submit"]').attr('disabled','disabled');
       },
        success: function(data){
       
        $('button[type="submit"]').removeAttr('disabled');
       
         $('#alertBox').html(data).fadeIn();
      }
           
});
      });



// ============= delete data from database============= //
$(document).on('click','.delete',function(e){
     
     var el=$(this);
     var id=$(this).attr('id');
     var name = $(this).attr('name');
    
     if ($('#confirmBox').css("display") == "none") {
      $('#confirmBox').fadeIn();
   
      $('#confirmBox').find('button').on('click', function(){
      
         if($(this).val()==1){

            $.ajax({    
        type: "GET",
        url: "scripts/backend-script.php", 
        data:{deleteId:id, deleteData:name},            
        dataType: "html",                  
        success: function(data){ 
                      
            $("#showTable").html(data); 
            $('#alertBox').html(data).fadeIn();
            el.parents('tr').remove();
                
        }

    });

         }

        $('#confirmBox').fadeOut(); 

      })
   
     }
 
});


// === display alert message within a time interval ====== //
 window.setInterval(function(){
 	 if ($('#alertBox').css("display") == "block") {
       $('#alertBox').fadeOut();
   }
   }, 3000);


// ====== open page  by clicking links ==============//
 $(document).on('click','a.content-link', function(e){
   e.preventDefault();
   history.pushState(null, '', $(this).attr('href'));
   var cat=getUrlParameter('cat');
   var subcat=getUrlParameter('subcat');
   var view=getUrlParameter('view');
   var edit=getUrlParameter('edit');
   
   if(cat!='' && subcat!=''){
     $.ajax({    
        type: "GET",
        url: "scripts/dynamic-page.php", 
        data:{
          cat:cat,
          subcat,
          view:view,
          edit:edit},            
        dataType: "html",                  
        success: function(data){ 
                      
           $('#dynamic-page').html(data); 
            
            
                
        }
   

    });
}else{
    $('#dynamic-page').html("This file does not exist"); 
}
  
 });
 

  // get query string value from url
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

$(document).ready(function(){
	$('.sta-tus').click(function(){
    var $this = $(this);
var value=$(this).val()=='Approved'? true :false;
var dataid=$(this).data('id');

jQuery.ajax({
        url: "scripts/dynamic-page.php",
        method: "POST",
        data:{dataid:dataid,
			value:value
		       },
        success:function(response){
         
            $this.siblings('.print-status').text($this.val())
       $this.siblings('.sta-tus').hide();
          
            $this.hide();

            console.log(response);
          }


		})
	})
 
$('.click-edit').click(function(){
  var view=$(this).data('id');

  // console.log(view);
  jQuery.ajax({
    url: "scripts/dynamic-page.php",
    method: "POST",
    data:"view="+view,
    success:function(response){
        $('.Edit-login').html(response);  
    $('.Edit-login').show();
  
    console.log(response);
}
    })
    }) 
    $(document).on('click','.close-log',function(){
      $('.Edit-login').hide();

  })






  $("td.edit-vehical:not(.except-td)").click(function(){
    var view_veh=$(this).data('id');
  
    console.log(view_veh);
    jQuery.ajax({
      url: "scripts/dynamic-page.php",
      method: "POST",
      data:"view_veh="+view_veh,
      success:function(res){
          $('.edit_veh_detail').html(res);  
      $('.edit_veh_detail').show();
    
      console.log(res);
  }
      })
      }) 
      $(document).on('click','.close-vehical',function(){
        $('.edit_veh_detail').hide();
  
    })

    $('.preview-booking').click(function(){
      var prvw_booking=$(this).data('id');
    
      console.log(prvw_booking);
      jQuery.ajax({
        url: "scripts/dynamic-page.php",
        method: "POST",
        data:"prvw_booking="+prvw_booking,
        success:function(res){
            $('.preview_carbooking').html(res);  
        $('.preview_carbooking').show();
      
        // console.log(res);
    }
        })
        }) 
        $(document).on('click','.close-booking',function(){
          $('.preview_carbooking').hide();
    
      })



      $('.view-review').click(function(){
        var view_review=$(this).data('id');
      
        console.log(view_review);
        jQuery.ajax({
          url: "scripts/dynamic-page.php",
          method: "POST",
          data:"view_review="+view_review,
          success:function(resp){
              $('.user_rvw').html(resp);  
          $('.user_rvw').show();
        
          console.log(resp);
      }
          })
          }) 
          $(document).on('click','.close-review',function(){
            $('.user_rvw').hide();
      
        })
  

        $(document).on('click','#upd-btn',function(){
          var rvw_id=$('.rvw_id').val();
          var rating=$('.rating').val();
          var reviews=$('.reviews').val();
// console.log(rvw_id);

          jQuery.ajax({
            url: "scripts/dynamic-page.php",
            method: "POST",
            data:{rvw_id:rvw_id,
              rating:rating,
              reviews:reviews
            },
            success:function(resp){
          $('.user_rvw').hide();
            console.log(resp);
        }
        })
});

// $('.show_text').click(function(){
//   var show_text=$(this).text();
//   $('#ul-li-content').text(show_text);
// })


});
