<br><br>
<?php
//   $sql1="SELECT * FROM contact_details ORDER BY id DESC LIMIT 0,1";
//   $res1       = $conn->query($sql1);
//   $data       = $res1->fetch_assoc();
//   $email      = !empty($data['email'])?$data['email']:'';
//   $mobile     = !empty($data['mobile'])?$data['mobile']:'';
//   $address    = !empty($data['address'])?$data['address']:'';
//   $google_map = !empty($data['google_map'])?$data['google_map']:'';
//   $facebook   = !empty($data['facebook'])?$data['facebook']:'';
//   $google_plus   = !empty($data['google_plus'])?$data['google_plus']:'';
//   $twitter    = !empty($data['twitter'])?$data['twitter']:'';
//   $linkedin   = !empty($data['linkedin'])?$data['linkedin']:'';
//   $youtube    = !empty($data['youtube'])?$data['youtube']:'';
//   $instagram  = !empty($data['instagram'])?$data['instagram']:'';
//   $id         = !empty($data['id'])?$data['id']:'';



?>

<div class="content-box">

	<div class="row">
		<div class="col">
		<h4>Login Detail</h4>
		</div>
		
	</div>
	<br>
	<div class="row">
		<div class="col">
	<div class="table-responsive">
		<table class="table contact-table">
			<tr >
				<th>User Id</th>
				<th>User Name</th>
				<th>Full Name</th>
				<th>Email Id</th>
				<th>Moile Number</th>
				<th>Driving Licence  Number</th>
				<th>Gender</th>
				<th>City</th>
				<th>File</th>
			

			</tr>
						<?php
  $sql1="SELECT * FROM login_detail ";
  $res1= $conn->query($sql1);
  if($res1->num_rows>0)
  {
   while($data=$res1->fetch_assoc()){
   	?>
   	<tr class="click-edit" data-id="<?php echo $data['Id']?>">
   		
		
   		<td><?php echo $data['Id']; ?></td>
   		<td><?php echo $data['user_name']; ?></td>
   		<td><?php echo $data['full_name']; ?></td>
   	
   		<td><?php echo $data['email_id']; ?></td>
   		<td><?php echo $data['mobile_no']; ?></td>
   		<td><?php echo $data['drv_lcen_no']; ?></td>
   		<td><?php echo $data['gender']; ?></td>
   		<td><?php echo $data['city']; ?></td>
   		<td><?php echo $data['file']; ?></td>
		   
   		
		 


   		
   		<!-- <td><a  href="dashboard.php?cat=website-content&subcat=home-content&view=*/" class="text-secondary content-link"><i class='far fa-eye'></i></a></td>
        <td><a href="dashboard.php?cat=website-content&subcat=add-home-content&edit=" class="text-success content-link"><i class=' far fa-edit'></i></a></td>
        <td><a href="javascript:void(0)" class="text-danger delete"  name="home_content" id=""><i class='far fa-trash-alt'></i></a></td> -->

   	</tr>
   	<?php
   }
}else{

?>
<tr>
	<td colspan="6">No Admin Profile Data</td>
</tr>
<?php } ?>
		</table>

	
	</div>
</div>
</div>
	<!-----==================table content end===================-->

</div>

	<div class="container mx-auto Edit-login"  style="display:none;" >
		   </div





