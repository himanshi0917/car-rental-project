
<br><br>
<div class="content-box">
	
	<h4>Users Review</h4>
	<br>
	<div class="table-responsive">
		<table class="table view-table">
			<tr>
				<th>sr.no</th>
				<th>User Name</th>
				<th>Rating</th>
				<th >Review</th>
				
			

			</tr>
			<?php
  $sql1="SELECT r.review_id ,r.user_id,r.rating,r.review,l.full_name,l.file FROM login_detail l JOIN users_review r  ON  r.user_id=l.Id";
  $res1= $conn->query($sql1);
  if($res1->num_rows>0)
  {$j=1;
   while($data=$res1->fetch_assoc()){
   	?>
   	<tr class="view-review" data-id="<?php echo $data['review_id']?>">
   	
	   <td><?php echo $j; ?></td>
	   <td><?php echo $data['full_name']; ?></td>
   	<td><?php for($i=1;$i<=5;$i++){
if($data['rating']>=$i)
	 {
	  ?><span style="font-size:100%;color:hsl(46, 100%, 45%);">&starf;</span>
  <?php
       }
    else{
    ?>
	<span style="font-size:100%;color:black;">&starf;</span>
<?php
 }
 }
 ?>
</td>
   		<td class="set-rvw"><?php echo $data['review']; ?></td>
   		
   	

   		
   	</tr>
   	<?php
  $j++; }

}else{

?>
<tr>
	<td colspan="6">No Message</td>
</tr>
<?php } ?>


		</table>


		<div class="container mx-auto user_rvw"  style="display:none;" >
</div>
	</div>
</div>