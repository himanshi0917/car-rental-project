<br>
	<div class="row">
		<div class="col">
			<h4>Car-bookings Detail</h4>
		</div>
		<!-- <div class="col text-right">
			<a href="dashboard.php?cat=website-content&subcat=add-rented-content" ></a>
		</div> -->
	</div>
	<br>
	<div class="row">
		<div class="col">
	<div class="table-responsive">
		<table class="table">
			<tr >
				<th>Booking Id</th>
				<th>Car Brand/Model</th>
                <th>User name</th>
				<th>Booked from</th>
				<th>Booked till</th>
				<th>Status</th>
				


			</tr>
						<?php
  $sql1="SELECT l.full_name,v.car_brand,v.car_model,c.booking_id,c.avl_from,c.avl_till,c.status FROM login_detail l JOIN car_booking c ON l.Id=c.user_id JOIN vehical_host v ON v.Id=c.vech_id";
  $res1= $conn->query($sql1);
  if($res1->num_rows>0)
  {
   while($data=$res1->fetch_assoc()){
   	?>
   	<tr class="preview-booking" data-id="<?php echo $data['booking_id'] ?>">
   	
   		<td><?php echo $data['booking_id']; ?></td>
   		<td><?php echo $data['car_brand']." ".$data['car_model']; ?></td>
   		<td><?php echo $data['full_name']; ?></td>
   		<td><?php echo $data['avl_from']; ?></td>
   		<td><?php echo $data['avl_till']; ?></td>
   		<td><?php echo $data['status']; ?></td>
   		</tr>

   		



   		
   		<!-- <td><a  href="dashboard.php?cat=website-content&subcat=home-content&view=*/" class="text-secondary content-link"><i class='far fa-eye'></i></a></td>
        <td><a href="dashboard.php?cat=website-content&subcat=add-home-content&edit=" class="text-success content-link"><i class=' far fa-edit'></i></a></td>
        <td><a href="javascript:void(0)" class="text-danger delete"  name="home_content" id=""><i class='far fa-trash-alt'></i></a></td> -->

   
   	<?php
   }
}else{

?>
<tr>
	<td colspan="6">No Admin Profile Data</td>
</tr>
<?php } ?>
		</table>
		<div class="container mx-auto preview_carbooking"  style="display:none;" >
</div>
	</div>
</div>
</div>
	<!-----==================table content end===================-->


</div>