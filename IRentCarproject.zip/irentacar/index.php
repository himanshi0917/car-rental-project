﻿<?php
session_start();

include 'config.php';
 




if (isset($_POST["submitto_reg"])){
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
$fullname= $fname." ". $lname;
$username=$fname."_". $lname;
    $password = $_POST["password"];
    $encrypt_pwd = crypt($password,'$1$rasmusle$');
    $email = $_POST["email"];

 // echo "$fullname.$password.$email";
    
    $query = "INSERT INTO login_detail (user_name,full_name,password,email_id) VALUES('$username','$fullname','$encrypt_pwd','$email')";
  
   $consuc= mysqli_query($conn,$query);

// if(!$name){
//     die("not submited :". mysqli_error($conn));
//    }
// else{
//     echo"successfuly submitted";
// }
}
// if(isset($_POST['submitto_login']))
// {
//     $username=$_POST['username'];
//     $userpassword=$_POST['userpassword'];
    

// $query= "SELECT  * FROM login_detail WHERE user_name='$username' ";

// $consuc= mysqli_query($conn,$query);
// $login=mysqli_num_rows($consuc);
// if($login){
//     $email_pas=mysqli_fetch_assoc($consuc);
 


// $db_pas= $email_pas['password'];

// echo "<pre>";
// print_r($db_pas);
// echo "</pre>";

// if(password_verify($userpassword,$db_pas)){
 
//     $_SESSION['users']=array('id'=>$email_pas['Id'],
//                               'full_name'=>$email_pas['full_name'],
//                                 'city'=>$email_pas['city'],
//                                    'u_name'=>$email_pas['user_name']);

  

//     echo "login sucessful";
//     header("Location: http://localhost/irentacar/profile.php");
// }
// else 
// {
//     echo "incorrect password";
// }
// }

// else{
    
//     echo "invalid email";
// }
// }


$que_to_show="SELECT * FROM vehical_host";

$exec_toshow=mysqli_query($conn,$que_to_show);






// $id=$_SESSION['users']['id'];





//header("Location: http://localhost/irentacar/index.php");
?>


<?php
include 'header.php';
?>

<!-------------------- End of Header------------------------->
    <!-------------------- Main Banner--------------------------->
    <div class="bg-[url('images/banner.jpg')] bg-bottom bg-no-repeat px-2.5 pt-20 pb-44">
        <div class="container mx-auto flex">
            <div class="w-2/5">
                <h3 class="text-darkblue font-roboto font-medium text-[28px] leading-[35px] uppercase pb-5"> Rent A Car
                </h3>
                <h1
                    class="text-white font-roboto font-bold text-6xl pb-10 leading-tight drop-shadow-[0_4px_4px_rgba(0, 0, 0, 0.51)]">
                    Rent Your Dream Car With Us </h1> <a href="Filters.php" class="cursor-pointer"><button
                        class="font-roboto text-lg bg-darkblue rounded-full text-white font-[800] py-5 px-10 uppercase tracking-widest float-left">
                        Find Cars</button></a>
            </div>
        </div>
    </div> <!-------------------- End of Main Banner----------------------->
    <!-------------------- Pickup Form------------------------------>
    <div class="container mx-auto">
        <div class="bg-white w-full shadow p-10 rounded-[25px] -mt-16 shadow-[0_4px_15px_rgba(0,0,0,0.25)]">
            <?php $data_allcars=mysqli_fetch_assoc($exec_toshow);?>
            <form class="flex space-x-6"   action="Filters.php" method="POST" >
                <div class="w-full"> <label class="text-headingColor font-roboto font-bold text-xl">Pick Up
                        Location</label><br /> <input name="city" type="text" required 
                        class="border mt-2 w-full focus:outline-none focus:border-darkblue font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/location-icon.svg')] bg-no-repeat bg-[98%_center]"
                        placeholder="City, State"   /> </div>
                   
                        
                       
                <div class="w-full"> <label class="text-headingColor font-roboto font-bold text-xl">Pick & Drop
                        Date</label><br />
                    <input type="text" name="datetimes" 
                        class="single   focus:outline-none focus:border-darkblue border mt-2 w-full font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/calender-icon.svg')] bg-no-repeat bg-[98%_center]" />
                </div>
                <div class="w-3/6"> <label></label><br /> <a href="/irentacar/Filters.php"> <input type="submit"
                            class="cursor-pointer mt-2 font-roboto text-lg bg-darkblue rounded-full text-white font-[800] py-4 px-20 uppercase tracking-widest"
                            value="FIND A CAR"  id="find" /></a></div>

        </div>
        </form>
    </div>
    </div> <!-------------------- End of Pickup Form----------------------------->
    <!-------------------- Featured Vechile ------------------------------>
    <div class="w-2/4 text-center p-50 inline-block mt-20 mb-10 flex flex-col mx-auto">
        <h2 class="font-roboto text-headingColor font-bold text-[45px]"> <img class="inline-block mr-4"
                src="images/rectangle.png" />Featured Vehicles<img class="inline-block ml-4"
                src="images/rectangle.png" /> </h2>
        <p class="font-roboto text-paragraphColor pb-5 font-medium text-lg"> Lorem ipsum dolor sit
            amet, consectetur do eiusmod incididunt ut abore et dolore magna aliqua. </p>
    </div>
    <div class="flex flex-wrap w-full justify-center mx-auto" id="tabs-id">
        <div class="w-[45rem] rounded-full space-x-3">
            <ul class="flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row divide-x divide-[#2AD1EB]">
                <li class="flex-auto cursor-pointer text-center"> <a
                        class="text-lg uppercase font-bold  text-white font-roboto px-5 py-4 rounded-tl-full rounded-bl-full block leading-normal bg-headingColor"
                        onclick="changeAtiveTab(event,'tab-cars')"> All Cars </a> </li>
                <li class="flex-auto cursor-pointer text-center"> <a
                        class="text-lg uppercase font-bold  text-white font-roboto px-5 py-4 block leading-normal bg-darkblue"
                        onclick="changeAtiveTab(event,'tab-hatchback')"> Hatchback </a> </li>
                <li class="flex-auto cursor-pointer text-center"> <a
                        class="text-lg uppercase font-bold  text-white font-roboto px-5 py-4 block leading-normal bg-darkblue"
                        onclick="changeAtiveTab(event,'tab-sedan')"> Sedan </a> </li>
                <li class="flex-auto cursor-pointer text-center"> <a
                        class="text-lg uppercase font-bold  text-white font-roboto px-5 py-4 block leading-normal bg-darkblue"
                        onclick="changeAtiveTab(event,'tab-suv')"> SUV </a> </li>
                <li class="flex-auto cursor-pointer text-center"> <a
                        class="text-lg uppercase font-bold text-white font-roboto px-5 py-4 block rounded-tr-full rounded-br-full leading-normal bg-darkblue"
                        onclick="changeAtiveTab(event,'tab-muv')"> MUV </a> </li>
            </ul>
        </div>
        <div class="relative flex flex-col break-words bg-white w-full mb-6">
            <div class="container mx-auto">
                <div class="px-4 py-5 flex-auto">
                    <div class="tab-content tab-space">
                        
                        <div class="block gap-8 grid grid-cols-3" id="tab-cars">
                        <?php
                        while($data_allcars=mysqli_fetch_assoc($exec_toshow)){
                            // echo "<pre>";
                            // print_r($exec_toshow);
                            // echo "</pre>";
                            // echo "<pre>";
                            // print_r($data_allcars);
                            // echo "</pre>";
                      
                        ?>
                            <div class="rounded-[25px] w-full border border-borderColor"> <img src="<?php echo $data_allcars['car_img'] ?>"
                                    class="rounded-tl-[25px] rounded-tr-[25px]" />
                                <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                     <?php echo $data_allcars['seat_cap'] ?></div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                    <?php echo $data_allcars['fuel_type'] ?></div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                    <?php echo $data_allcars['transm_type'] ?></div>
                                </div>
                                <div class="py-8 mx-auto block text-center">
                                    <h3
                                        class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">
                                        <?php echo $data_allcars['car_brand'] ."". $data_allcars['car_model']?></h3>
                                    <p class="font-roboto font-normal text-base text-center text-paragraphColor"><?php echo "Start
                                        from ".$data_allcars['price']."/per day" ?> </p>
                                    <div class="mt-7 mb-1"> <a href="Booking-details.php?vech_id=<?php echo $data_allcars['Id']?>" class="cursor-pointer">
                                            <button
                                                class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">
                                                Rent now </button></a> </div>
                                </div>
                            </div>
                       
                            <?php
                        }
                        ?>
                        </div>
                          
                        <div class="hidden" id="tab-hatchback">
                          <?php 
                          $que_to_show="SELECT segment FROM vehical_host where segment='Hatchback'";
                          $exec_toshow=mysqli_query($conn,$que_to_show);
                         if(mysqli_num_rows($exec_toshow)>0){
                            while($data_allcars=mysqli_fetch_assoc($exec_toshow)){
                                // echo "<pre>";
                                // print_r($exec_toshow);
                                
                                // echo "</pre>";
                                // echo "<pre>";
                                // print_r($data_allcars);
                                // echo "</pre>";
                                // if($data_allcars['segment']=="Hatchback")
                                // {

                                    ?>
                                    <div class="rounded-[25px] flex flex-col w-1/3 border border-borderColor"> <img
                                    src="images/car5.jpg" class="rounded-tl-[25px] rounded-tr-[25px]" />
                                <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        2020 </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Diesel </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Automatic </div>
                                </div>
                                <div class="py-8 mx-auto block text-center">
                                    <h3
                                        class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">
                                        cHEVEROLET M Class </h3>
                                    <p class="font-roboto font-normal text-base text-center text-paragraphColor"> Start
                                        from 45$/per day </p>
                                    <div class="mt-7 mb-1"> <a href="Booking-details.php" class="cursor-pointer">
                                            <button
                                                class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">
                                                Rent now </button></a> </div>
                                </div>
                            </div>
                            <?php
                                }
                               
                            }
                    else{
                                    echo "no record found";
                                }
                        ?>
                            
                        </div>
                        <div class="hidden" id="tab-sedan">
                            <?php 
                            $que_to_show="SELECT segment FROM vehical_host where segment='Sedan'";
                            $exec_toshow=mysqli_query($conn,$que_to_show);
                           if(mysqli_num_rows($exec_toshow)>0){
                            while($data_allcars=mysqli_fetch_assoc($exec_toshow)){
                        //  echo $exec_toshow;
                        //  echo "<pre>";
                        //  print_r($data_allcars);
                        //  echo "</pre>";

                                // if($data_allcars['segment']!=="Sedan")
                                // {

                                    ?>
                            <div class="rounded-[25px] flex flex-col w-1/3 border border-borderColor"> <img
                                    src="images/car4.jpg" class="rounded-tl-[25px] rounded-tr-[25px]" />
                                <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        2020 </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Diesel </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Automatic </div>
                                </div>
                                <div class="py-8 mx-auto block text-center">
                                    <h3
                                        class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">
                                        fERRARI M Class </h3>
                                    <p class="font-roboto font-normal text-base text-center text-paragraphColor"> Start
                                        from 45$/per day </p>
                                    <div class="mt-7 mb-1"> <a href="Booking-details.php" class="cursor-pointer">
                                            <button class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">
                                                Rent now </button></a> </div>
                                </div>
                            </div>
                            <?php
                        }
                       
                    }
            else{
                            echo "no record found";
                        }
                ?>
                        </div>
                        <div class="hidden" id="tab-suv">
                            <?php 
                           $que_to_show="SELECT segment FROM vehical_host where segment='SUV'";
                           $exec_toshow=mysqli_query($conn,$que_to_show);
                          if(mysqli_num_rows($exec_toshow)>0){
                            while($data_allcars=mysqli_fetch_assoc($exec_toshow)){
                              

                                // if($data_allcars['segment']=="SUV")
                                // {

                                    ?>
                            <div class="rounded-[25px] flex flex-col w-1/3 border border-borderColor"> <img
                                    src="images/car6.jpg" class="rounded-tl-[25px] rounded-tr-[25px]" />
                                <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        2020 </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Diesel </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Automatic </div>
                                </div>
                                <div class="py-8 mx-auto block text-center">
                                    <h3
                                        class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">
                                        rANGE rOVER M Class </h3>
                                    <p class="font-roboto font-normal text-base text-center text-paragraphColor"> Start
                                        from 45$/per day </p>
                                    <div class="mt-7 mb-1"> <a href="Booking-details.php" class="cursor-pointer">
                                            <button
                                                class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">
                                                Rent now </button></a> </div>
                                </div>
                            </div>
                            <?php
                        }
                       
                    }
            else{
                            echo "no record found";
                        }
                ?>
                        </div>
                        <div class="hidden" id="tab-muv">
                            <?php 
                             $que_to_show="SELECT segment FROM vehical_host where segment='MUV'";
                             $exec_toshow=mysqli_query($conn,$que_to_show);
                            if(mysqli_num_rows($exec_toshow)>0){
                            while($data_allcars=mysqli_fetch_assoc($exec_toshow)){
                             

                                // if($data_allcars['segment']=="MUV")
                                // {
                                    ?>
                            <div class="rounded-[25px] flex flex-col w-1/3 border border-borderColor"> <img
                                    src="images/car3.jpg" class="rounded-tl-[25px] rounded-tr-[25px]" />
                                <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        2020 </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Diesel </div>
                                    <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">
                                        Automatic </div>
                                </div>
                                <div class="py-8 mx-auto block text-center">
                                    <h3
                                        class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">
                                        bmw benz M Class </h3>
                                    <p class="font-roboto font-normal text-base text-center text-paragraphColor"> Start
                                        from 45$/per day </p>
                                    <div class="mt-7 mb-1"> <a href="Booking-details.php" class="cursor-pointer">
                                            <button
                                                class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">
                                                Rent now </button></a> </div>
                                </div>
                            </div>
                            <?php
                        }
                       
                    }
            else{
                            echo "no record found";
                        }
                ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div> <!-------------------- End of Featured Vechile ----------------------->
    <!-------------------- Book Process ------------------------------>
    <div class="bg-darkblue w-full py-20 ">
        <div class="container mx-auto">
            <h3
                class="font-roboto w-4/12 flex flex-col mx-auto text-center text-white font-bold text-[45px] leading-[55px] mb-20">
                Our Car Rental Booking Process </h3>
            <div class="flex gap-6 mb-10">
                <div
                    class="w-full bg-white text-center border rounded-[25px] pb-9 px-5 space-y-3 outline outline-offset-15 outline-white outline-4">
                    <img src="images/search.svg" class="mx-auto -mt-[60px] z-10 relative" />
                    <h4 class="font-roboto font-bold text-darkblue text-xl pt-5"> Browse Our Inventory </h4>
                    <p class="text-paragraphColor font-roboto font-normal text-base"> Cras sit amet mi non orci pretium
                        consectetur. Donec iaculis ante ac sollicitudin luctus. Phasellus ut lacus lacus. </p>
                </div> <img class="flex" src="images/arrow.svg" />
                <div
                    class="w-full bg-white text-center border rounded-[25px] pb-9 px-5 space-y-3 outline outline-offset-15 outline-white outline-4">
                    <img src="images/book-car.svg" class="mx-auto -mt-[60px] z-10 relative" />
                    <h4 class="font-roboto font-bold text-darkblue text-xl pt-5"> Book A Car </h4>
                    <p class="text-paragraphColor font-roboto font-normal text-base"> Cras sit amet mi non orci pretium
                        consectetur. Donec iaculis ante ac sollicitudin luctus. Phasellus ut lacus lacus. </p>
                </div> <img class="flex" src="images/arrow.svg" />
                <div
                    class="w-full bg-white text-center border rounded-[25px] pb-9 px-5 space-y-3 outline outline-offset-15 outline-white outline-4">
                    <img src="images/pickup.svg" class="mx-auto -mt-[60px] z-10 relative" />
                    <h4 class="font-roboto font-bold text-darkblue text-xl pt-5"> Car Delivery Or Pick Up </h4>
                    <p class="text-paragraphColor font-roboto font-normal text-base"> Cras sit amet mi non orci pretium
                        consectetur. Donec iaculis ante ac sollicitudin luctus. Phasellus ut lacus lacus. </p>
                </div>
            </div>
        </div>
    </div> <!-------------------- End of Book Process --------------------------->
    <!--------------------------- Testimonial ---------------------------------->


    <?php
    $review_query="SELECT r.review_id ,r.user_id,r.rating,r.review,l.full_name,l.file FROM login_detail l JOIN users_review r  ON  r.user_id=l.Id";
    $execu_review_query=mysqli_query($conn,$review_query);
    
    ?>
    <div class="w-full mx-auto text-center py-12">
        <div class="container mx-auto">
            <h3 class="font-roboto text-headingColor font-bold text-[45px]"> Testimonials </h3>
            <div id="default-carousel" class="relative" data-carousel="static"> <!-- Carousel wrapper -->
                <div class="overflow-hidden relative h-56 rounded-lg sm:h-64 xl:h-80 2xl:h-96"> <!-- Item 1 -->

                <?php
                while($fetch_review=mysqli_fetch_assoc($execu_review_query)){
                    // echo "<pre>";
                    // print_r($fetch_review);
                    // echo "</pre>";

                    ?>
                    <div class="hidden duration-700 ease-in-out space-y-4 pt-5" data-carousel-item> <img
                            src="images/quote.svg" class="block mx-auto" alt="quote" />
                        <p class="text-paragraphColor font-roboto font-medium text-base w-4/6 mx-auto"><?php echo $fetch_review['review'] ?>  </p>
                        <img src="<?php echo $fetch_review['file'] ?> " class="block mx-auto " width="50px" alt="John" />
                        <h4 class="font-roboto text-headingColor font-bold text-xl"> <?php echo $fetch_review['full_name'] ?> </h4>
                        <div class="flex items-center justify-center">

                        <?php for($i=1;$i<=5;$i++){
                          

                                if($fetch_review['rating']>=$i)


                                {

                                    ?>
                             <svg class="w-5 h-5 text-yellow-400"
                                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> 
                            <?php
                                  }
                                  else{
                                    ?>
                                      <svg class="w-5 h-5 text-gray-300 dark:text-white" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg>
                            <?php
                                  }
                            }
                             ?></div>
                            
                    </div>
                     <?php
                            }
                            ?>
                                 
                          
                            
                            <!-- Item 2 -->
                    <!-- <div class="hidden duration-700 ease-in-out space-y-4 pt-5" data-carousel-item> <img
                            src="images/quote.svg" class="block mx-auto" alt="..." />
                        <p class="text-paragraphColor font-roboto font-medium text-base w-3/6 mx-auto"> Lorem ipsum
                            dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. consuetudi- um lectorum commodo consequat. </p> <img
                            src="images/john.svg" class="block mx-auto" alt="John" />
                        <h4 class="font-roboto text-headingColor font-bold text-xl"> John Doe </h4>
                        <div class="flex items-center justify-center"> <svg class="w-5 h-5 text-yellow-400"
                                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-gray-300 dark:text-white" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> </div>
                    </div>  Item 3 
                    <div class="hidden duration-700 ease-in-out space-y-4 pt-5" data-carousel-item> <img
                            src="images/quote.svg" class="block mx-auto" alt="..." />
                        <p class="text-paragraphColor font-roboto font-medium text-base w-3/6 mx-auto"> Lorem ipsum
                            dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. mutationem consuetudi- um lectorum commodo consequat. </p> <img
                            src="images/john.svg" class="block mx-auto" alt="John" />
                        <h4 class="font-roboto text-headingColor font-bold text-xl"> John Doe </h4>
                        <div class="flex items-center justify-center"> <svg class="w-5 h-5 text-yellow-400"
                                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> <svg class="w-5 h-5 text-gray-300 dark:text-white" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg> </div>
                    </div> -->
                </div> <!-- Slider indicators -->
                <div class="flex absolute bottom-5 left-1/2 z-30 space-x-3 -translate-x-1/2"> <button type="button"
                        class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 1"
                        data-carousel-slide-to="0"></button> <button type="button" class="w-3 h-3 rounded-full"
                        aria-current="false" aria-label="Slide 2" data-carousel-slide-to="1"></button> <button
                        type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 3"
                        data-carousel-slide-to="2"></button> </div> <!-- Slider controls --> <button type="button"
                    class="flex absolute top-0 left-0 z-30 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none"
                    data-carousel-prev> <span
                        class="inline-flex justify-center items-center w-8 h-8 rounded-full sm:w-10 sm:h-10 group-focus:ring-1 group-focus:ring-black dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                        <img src="images/left-arrow.svg"> <span class="hidden">Previous</span> </span> </button> <button
                    type="button"
                    class="flex absolute top-0 right-0 z-30 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none"
                    data-carousel-next> <span
                        class="inline-flex justify-center items-center w-8 h-8 rounded-full sm:w-10 sm:h-10 group-focus:ring-1 group-focus:ring-black dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                        <img src="images/right-arrow.svg"> <span class="hidden">Next</span> </span> </button>
            </div>
        </div>
        <?php   if(isset($_SESSION['users']['id'])){
    
    ?> 
        <div class="add_review">
        <a class="bg-darkblue"  href="javascript:void(0)">Add Review</a>
        </br>
    </br>
        <p class="review-response"></p>
    </div>
    </div>
    <?php
        }
        ?>
    
    <form action="index.php" method="post">
    <div class="review-form" style="display:none">

	      	<div class="modal-header">
	        	<h5 class="modal-title">Submit Review</h5>
	        	<button type="button" class="close" id="close-rvew" data-dismiss="modal" aria-label="Close">
	          		<span aria-hidden="true">close</span>
	        	</button>
	      	</div>
            <div class="star-section">
	      	<div class="star-rating">
  <span class="star" data-rating="1">
    <input type="checkbox" class="rating-checkbox"  id="star1" value="1" >
  </span>
  <span class="star" data-rating="2">
  <input type="checkbox" class="rating-checkbox" id="star2" value="2">
  </span>
  <span class="star" data-rating="3">
  <input type="checkbox" class="rating-checkbox" id="star3" value="3" >
  </span>
  <span class="star" data-rating="4">
  <input type="checkbox" class="rating-checkbox" id="star4" value="4">
  </span>
  <span class="star" data-rating="5">
  <input type="checkbox" class="rating-checkbox"  id="star5" value="5">
  </span>
  
</div>
<input type="hidden" class="user_id" value="<?php echo $_SESSION['users']['id']; ?>">


           
	        	</div>
	        	<div class="form-group">
                    <label class="review-label" for="user_review">Write your review</label>
                    <br>
	        		<textarea name="user_review" id="user_review" class="user_review" placeholder="Type Review Here" style="width: 420px;padding:15px;"
}></textarea>
	        	</div>
	        	<div class="form-group text-center mt-4 review-btn">
	        		<button type="button"  name="save_review" class="btn btn-primary" id="save_review">Submit</button>
	        	</div>
	      	</div>
        </form>
    	</div>
    <!---------------------------End of Testimonial ----------------------->
    <!--------------------------- Footer ---------------------------------->








<?php
include 'footer.php';

?>