<?php

ini_set("display_errors",1);
session_start();
if(!isset($_SESSION['users']['id'])){
  header("location: http://localhost/irentacar/index.php");
}
include 'config.php';

$que_fetfo_ren="SELECT * FROM vehical_host ";

$fet_fo_ren=mysqli_query($conn,$que_fetfo_ren);

// $data_for_rent=mysqli_fetch_assoc($fet_fo_ren);


// $sql_z    =   "SELECT * FROM vehical_host WHERE notary_firstname LIKE '$selected_val%' OR notary_lastname LIKE '$selected_val%' OR notary_email LIKE '$selected_val%' OR notary_address_zip LIKE '$selected_val%' OR notary_address_city LIKE '$selected_val%'";


$get_ct_date="";
if(isset($_POST['city'])){

  // echo "<pre>";
  // print_r($_POST);
  // echo"</pre>";
 
  $city=$_POST['city'];
  $date=$_POST['datetimes'];
  $datetime= explode("-",$date);
  $strtfromdate=str_replace("/","-",trim($datetime[0]));
  $endtilldate=str_replace("/","-",trim($datetime[1]));
// echo"<pre>";
//   print_r($strtfromdate);
//   echo"</pre>";
//   echo $endtilldate;

$value=array($city,$strtfromdate,$endtilldate);
$get_ct_date=json_encode($value);

// echo $get_ct_date;


  // $search_query="SELECT * FROM vehical_host WHERE city LIKE '%$city%' AND available_from>= '$strtdate'' AND available_till<='$enddate'";
  // $exec_que=mysqli_query($conn,$search_query);

  // echo $exec_que;


}



?>












<?php
include 'header.php';
?>

  <!-------------------- End of Header------------------------->







  <!-------------------- Filters --------------------------->

<input type="hidden" id="load_data" value="<?php echo $get_ct_date;?>"/>

  <div class="bg-white pt-20">

    <div class="container mx-auto">

        <div class="w-full flex-row flex gap-6">

        <div class="w-2/6 flex flex-col">

        <div class="bg-darkblue rounded-[15px] px-2.5 py-5 mb-8">

    <div class="flex justify-between">

        <h1 class="font-roboto font-bold text-xl text-white">Sort & Filters</h1>

        <a href="javascript:vold(0)" class="font-roboto text-base text-white hover:opacity-80"><button>Reset all</button></a>

   </div>

   <div class="w-full flex flex-col mt-4 mb-2">

   <select name="filter" id="filter"class="text-paragraphColor focus:outline-none font-roboto font-normal text-base rounded-full pl-2 pr-12 py-5"> 

   
   <option  value="">select option </option>
    <option  value="HightoLow">High to Low</option>

    <option value="LowtoHigh">Low to High</option>

    <option  value="LatestProucts">Latest cars</option>

</select>  

  </div>

</div>



<!-------------------- End of Filters--------------------->







<!--------------------Search Bar--------------------->



<input type="search" name="search" placeholder="Search Car..." class="bg-[url('images/search-icon.png')] bg-no-repeat bg-[95%] rounded-[30px] border border-borderColor px-4 py-4 text-paragraphColor focus:border-darkblue transition-all focus:outline-none font-roboto font-normal text-base w-full">



<div class="border border-lightColor bg-lightColor rounded-[15px] my-8 px-2.5 pt-5 pb-8">

<h3 class="font-roboto font-medium text-base mb-3">Segment</h3>

<form class="grid grid-cols-3 gap-3"> 

<label for="car" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

<img src="images/suv-car-icon.png" class="mx-auto block">

<input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black" id="car" name="segment" value="Hatchback">

Hatchback</label>



<label for="suv" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

  <img src="images/suv-car-icon.png" class="mx-auto block">

  <input type="checkbox" class="radio-btn mr-2 invisible block m-auto text-center font-normal text-base text-black" id="suv"name="segment" value="SUV">

SUV</label>



<label for="muv" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

  <img src="images/suv-car-icon.png" class="mx-auto block">

  <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black" id="muv" name="segment" value="MUV">

MUV</label>



<label for="sedan" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue hover:border-darkblue  hover:text-white cursor-pointer">

  <img src="images/suv-car-icon.png" class="mx-auto block">

  <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal px-4 pt-6 text-base text-black" id="sedan" name="segment" value="Sedan">Sedan

</label>

</form>

</div>



<div   class="border border-lightColor bg-lightColor rounded-[15px] my-8 px-2.5 pt-5 pb-8 SetType">

  <h3 class="font-roboto font-medium text-base mb-3">Fuel Type</h3>

  <form class="grid grid-cols-3 gap-3"> 

  <label for="diesel" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

    <img src="images/fuel-pump-diesel.png" class="mx-auto block">

  <input  type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="diesel" name="fuel-type" value="Diesel">

  Diesel</label>

  

  <label for="petrol" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

    <img src="images/fuel-pump-diesel.png" class="mx-auto block">

    <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="petrol" name="fuel-type" value="Petrol">
   Petrol</label>

  

  <label for="electric" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue hover:border-darkblue hover:text-white cursor-pointer">

    <img src="images/electric.png" class="mx-auto block">

    <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="electric" name="fuel-type" value="Electric">

    Electric</label>

  </form>

  </div>



  <div id="transm_type" class="border border-lightColor bg-lightColor rounded-[15px] my-8 px-2.5 pt-5 pb-8 SetType">

    <h3 class="font-roboto font-medium text-base mb-3">Transmission Type</h3>

    <form class="grid grid-cols-3 gap-3"> 

    <label  for="automatic" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

      <img src="images/automatic-icon.png" class="mx-auto block">

    <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="automatic" name="transm_type"  value="Automatic">

    Automatic</label>

    

    <label for="manual" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

      <img src="images/manual-icon.png" class="mx-auto block">

      <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="manual" name="transm_type" value="Manual">

      Manual</label>

    </form>

    </div>



    <div id="seat_type" class="border border-lightColor bg-lightColor rounded-[15px] my-8 px-2.5 pt-5 pb-8 SetType">

      <h3 class="font-roboto font-medium text-base mb-3">Seating Capacity</h3>

      <form class="grid grid-cols-3 gap-3"> 

      <label for="four-seater" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

        <img src="images/seater.png" class="mx-auto block">

      <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="four-seater" name="seat_cap" value="4 Seater">

      4 Seater</label>

      

      <label for="five-seater" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

        <img src="images/seater.png" class="mx-auto block">

        <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="five-seater" name="seat_cap"  value="5 Seater">

        5 Seater</label>

      

      <label for="six-seater" class="radio-btn bg-white rounded-[10px] text-center border border-borderColor px-4 pt-6 pb-4 hover:bg-darkblue  hover:border-darkblue hover:text-white cursor-pointer">

        <img src="images/seater.png" class="mx-auto block">

        <input type="checkbox" class="mr-2 invisible block m-auto text-center font-normal text-base text-black checkbox" id="six-seater" name="seat_cap"  value="6 Seater">

      6 Seater</label>

      </form>

      </div>



</div>   



<!--------------------End of Search Bar--------------------->







<!------------------------My Account------------------------->



<div class="w-4/6 mb-20">

<div class="w-full shadow-[0_4px_15px_rgba(0,0,0,0.25)] rounded-[15px] px-4 py-7 mb-16">

<form class="flex space-x-3">

<input  id="city" name="city" value="<?php if(isset($_POST['city'])){
  echo $city;}

  ;?>" plalceholder="search city..."
 
  class="border flex font-normal border-borderColor rounded-full py-4 pl-14 pr-5 text-paragraphColor bg-[url('images/location-icon.svg')] bg-no-repeat bg-[1rem] placeholder:text-headingColor font-roboto focus:border-darkblue w-2/3 transition-all focus:outline-none" 
 />

  <input type="text" name="datetimes" value="<?php if(isset($strtfromdate)&&($endtilldate)){
    echo $strtfromdate."".$endtilldate;
  }?> " id="date" class="focus:outline-none focus:border-darkblue border mt-2 w-full font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/calender-icon.svg')] bg-no-repeat bg-[98%_center]" />

 <!-- <input type="text" class="flex font-roboto border border-borderColor rounded-full w-1/3 py-4 px-3 bg-white text-darkblue placeholder:text-darkblue font-bold font-roboto focus:outline-none" placeholder="Start Date: ">

<input type="text" class="font-roboto border border-borderColor rounded-full w-1/3 py-4 px-3 bg-white text-darkblue placeholder:text-darkblue font-bold font-roboto focus:outline-none" placeholder="End Date: "> -->



</form>

</div>



<div class="block gap-8 grid grid-cols-2" id="tab-cars">

  <?php 
  while($data_for_rent=mysqli_fetch_assoc($fet_fo_ren)){
  ?>
  <div class="rounded-[25px] w-full border border-borderColor">

    
<a href="Booking-details.php?vech_id=<?php echo $data_for_rent['Id']?>">  <img src="<?= $data_for_rent['car_img']?>" class="rounded-tl-[25px] rounded-tr-[25px]" /></a>
    <div class="bg-lightColor divide-x divide-[#D9D9D9] grid grid-cols-3">

      <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">

      <?= $data_for_rent['seat_cap']?>

      </div>

      <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">

       <?= $data_for_rent['fuel_type']  ?>

      </div>

      <div class="font-roboto text-paragraphColor font-normal text-base py-3 text-center">

      <?= $data_for_rent['transm_type']  ?>

      </div>

    </div>

    <div class="py-8 mx-auto block text-center">

      <h3 class="font-roboto font-bold text-xl mb-2 text-center text-headingColor uppercase">

      <?= $data_for_rent['car_brand'].$data_for_rent['car_model'] ?>

      </h3>

      <p class="font-roboto font-normal text-base text-center text-paragraphColor">

      <?= "Start from ". $data_for_rent['price']."/per day" ?> 

      </p>

      <div class="mt-7 mb-1">

        <a href="Booking-details.php?vech_id=<?php echo $data_for_rent['Id']?>" class="cursor-pointer">

          <button class="font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-10 uppercase">

            Rent now

          </button></a>

      </div>

    </div>

  </div>
<?php
}
?>
  
</div>

</div>

</div>  
</div>
  </div>
   



  <!-------------------- End of My Account ----------------------->







  <!--------------------------- Footer --------------------------->


  <?php
include 'footer.php';
?>