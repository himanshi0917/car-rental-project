$(document).ready(function(){
    $("#log").click(function(){
        $(".login-page").css("display","block");
    });
    $("#sign").click(function(){
        $(".login-form").show();
        $(".register-form").hide();
    });
    $("#createac").click(function(){
        $(".register-form").show();
        $(".login-form").hide();
    });
    $(".close").click(function(){
        $(".login-page").hide();
    });

$('#anchor').click(function(e){
    e.preventDefault();
    $('#file').click();
});


$('#file').change(function(){
        var file= this.files[0];
        var reader= new FileReader();

        reader.onload=function(e){
            $('#show_img').attr('src',e.target.result);
        
         };

    reader.readAsDataURL(file);
   var file_data = file;
    var form_data = new FormData();
    form_data.append('file', file_data);
    
         jQuery.ajax({
            url: "ajax.php",
            method: "POST",
            contentType: false,
            processData: false,
            data: form_data,
            success:function(res){
                console.log(res);
            }

  });
    });

    $('[name="ins_file"]').change(function(){
        var file= this.files[0];
        var filetype = file.type;
        var filextntion=file.name;
        $(this).siblings('span').text(filextntion);
        $(this).siblings('img').hide();
        if(filetype=="application/pdf"){
            $(this).siblings('.pdf').show();
            $(this).siblings('.doc').hide();
        }
        if(filetype=="application/docx" || filetype=="application/msword"){
            $(this).siblings('.pdf').hide();
            $(this).siblings('.doc').show();
        };
console.log(filetype);

        $('[name="rc_file"]').change(function(){
            var file= this.files[0];
            var filext=file.name;
            var filetype = file.type;
            $(this).siblings('span').text(filext);
            $(this).siblings('img').hide();
            if(filext=="pdf"){
                $(this).siblings('.pdf').show();
                $(this).siblings('.doc').hide();
            }
            if(filext=="doc"){
                $(this).siblings('.pdf').hide();
                $(this).siblings('.doc').show();
            };

        });
    });
        // var reader= new FileReader();

        // reader.onload=function(e){
        //     $('#show_pic1').attr('src',e.target.result);
        
        //  };
        //  reader.readAsDataURL(file);
       


    //     $('#dropzone').change(function(){
    //         var file= this.files[0];
    //         var reader= new FileReader();
    
    //         reader.onload=function(e){
    //             $('#show_pic').attr('src',e.target.result);
            
    //          };
    //          reader.readAsDataURL(file);
    //         });

$('.show-vech').click(function(){
    var car=$(this).data('id');
    getCarById(car);
 
});

$(document).on('click','#back-btn',function(){
    $('.car-list').show();
    $('.single-car-info').hide();
});


$(document).on('click','#edit-btn',function(){
    $("#click-edit").show();

});

$(document).on('click','.close',function() {
    $("#click-edit").hide();
  });

 

  $(document).on('click','#save-btn',function() {
    var form=new FormData($('#save_data')[0]);

    jQuery.ajax({
        url: "ajax.php",
        method: "POST",
        data:form,
        contentType: false,
        processData: false,
        success:function(resp){
            console.log(resp);
         var form_id=  form.get('vech_id');
         $('#click-edit').hide();
         console.log(form_id);
         getCarById(form_id);



        }
        });
 });


 $(document).on('click','#update_data',function(){
    var form_out=new FormData($('#update_form')[0]);
    
    jQuery.ajax({
        url: "ajax.php",
        method: "POST",
        data:form_out,
        contentType: false,
        processData: false,
        success:function(respo){
            console.log(respo);
        }

 })




});

function getCarById(carid){


jQuery.ajax({
    url: "ajax.php",
    method: "POST",
    data:"carid="+carid,
    // dataType:'html',
    success:function(response){
        $('.single-car-info').html(response); 
        $('.car-list').hide();
        $('.single-car-info').show();
      
    } 

});

};


$(document).on('change keyup','[type="checkbox"],#filter,#date,#city,[type="search"]',function(){
   if(window.location.href =='http://localhost/irentacar/Filters.php'){
     var segment=$('[name="segment"]:checked').val();
    var fuel_type=$('[name="fuel-type"]:checked').val();
    var filter=$('[name="filter"]').val();
    var trsm_type=$('[name="transm_type"]:checked').val();
    var city=$('[name="city"]').val();
    var date=$('[name="datetimes"]').val();
    var seat_type=$('[name="seat_cap"]:checked').val();
    var search=$('[name="search"]').val();

    
// console.log();
// console.log(trsm_type);
// console.log(seat_type);

if(fuel_type!== undefined||trsm_type!==undefined|| seat_type!==undefined || search!==undefined || filter!==undefined || city!==undefined || date!=undefined){
    jQuery.ajax({
        url: "ajax.php",
        method: "POST",
        data:{
         search:search,
               city:city,
               date:date,
         filter:filter,
         fuel_type:fuel_type,
         segment:segment,
        transm_type:trsm_type,
         seat_cap:seat_type 
        
        },
        success:function(result){
          $('#tab-cars').html(result);
          console.log(result);
        }
    
    });
}
}
});

$('[type="checkbox"]').change(function(){
var checked=$(this).prop("checked");
// console.log(checked);
if(checked){
    $(this).parent().addClass('selectedopt');
    $(this).parent().siblings('label').removeClass('selectedopt').find('[type="checkbox"]').prop('checked',false);

}
else{
    $(this).parent().removeClass('selectedopt');
}

});

$(document).on('click','#Prvs-btn',function(){
    $('#rent-list').show();
    $('.pr-details').hide();
});
$('.prview-info').click(function(){
    var predata=$(this).data('id');
    getdataId(predata);
});
function getdataId(pdata){
    jQuery.ajax({
        url: "ajax.php",
        method: "POST",
        data:"pdata="+pdata,
        success:function(response){
            $('.pr-details').html(response); 
            $('#rent-list').hide();
            $('.pr-details').show();
         // console.log();
        } 
    
    });
    
    };
    $(document).on('click','#click_to_delete',function(){
    var cancel=$(this).data('id');
        Swal.fire({
            title: 'Are you sure to cancel ?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            if (result.isConfirmed) {
                jQuery.ajax({
                    url: "ajax.php",
                    method: "POST",
                    data:"cancel="+cancel,
                    success:function(response){
                    console.log(response,
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              ))
            }
          })
        }
    })

setTimeout(load,5000);
console.log(hello);
function load (){

var value= $('#load_data').val();
if(value!=""){
var filter_data= JSON.parse(value);

    jQuery.ajax({
        url: "Filter.php",
        method: "POST",
        data:{
            city:filter_data[0],
            date:filter_data[1]
        },
        success:function(result){
            $('#tab-cars').html(result);
            console.log(result);
        }
    
    });
}


}

});



$('.add_review').click(function(){
    $('.review-form').show();

})

$('#close-rvew').click(function(){
    $('.review-form').hide();
})

// $('#save_review').click(function(){
//     $('.review-form').hide();
// })

$(document).on('click','.rating-checkbox',function(){
         
   var star=$(this).val();
//    console.log(star);
   $('.rating-checkbox').prop('checked',false);
 for(var i=0; i<star; i++){
   
  $('.rating-checkbox').eq(i).prop('checked',true);

}

 $(document).on('click','#save_review',function(){
    var user_id=$('.user_id').val();
var rating=$('.rating-checkbox:checked').last().val();
 console.log(rating);
var review=$('.user_review').val();



// console.log(user_id);
          $.ajax({
            url: 'ajax.php',
            type: 'POST',
            data: { rating:rating,
                review:review ,
                user_id:user_id 
            },
            success: function(response) {
                $(".review-response").text("review submitted ");
                $('.review-form').hide();
              console.log(response);
            }
        });
          });
        });
    
        


        $('.click-to-login').click(function(e){
             e.preventDefault();
            var log_uname=$('.login_usrname').val();
            var log_pass=$('.login_pass').val();

            // console.log(log_uname);
            // console.log(log_pass);


        
            $.ajax({
                url: 'ajax.php',
                type: 'POST',
                data: { 
                    log_uname:log_uname ,
                    log_pass:log_pass 
                },
                success: function(re) {
                    
                    var res= JSON.parse(re);
                    console.log(res);
                    if (res['status'] == 'success') {
                        window.location.href = "http://localhost/irentacar/profile.php";
                   } 
                   else {

                         $('.error').text(res['message']).show();
                   }

                }
            })

        })


        $(function () {
            $("#togglePassword").click(function () {
                $(this).toggleClass("fa-eye fa-eye-slash");
               var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
                $(".login_pass").attr("type", type);
            });
        });

    })

