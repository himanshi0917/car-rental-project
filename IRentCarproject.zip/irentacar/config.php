<?php
mysqli_report(MYSQLI_REPORT_STRICT);
$conn=  mysqli_connect('localhost','root','','car_users');


?>