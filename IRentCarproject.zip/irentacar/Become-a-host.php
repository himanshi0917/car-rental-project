<?php
ini_set("display_errors",1);
session_start();
if(!isset($_SESSION['users']['id'])){
  header("location: http://localhost/irentacar/index.php");
};
 include 'config.php';

 $id=$_SESSION['users']['id'];
// $fetch= "SELECT * FROM login_detail where Id = '$id' ";
// $data= mysqli_query($conn,$fetch);
// $fetchdata=mysqli_fetch_assoc($data);


 if (isset($_POST["submit"])){
  $full_name = $_POST["full_name"];
  $car_brand = $_POST["car_brand"];
  $car_model = $_POST["car_model"];
  $city = $_POST["city"];
  $driven = $_POST["driven"];
  $fuel_type = $_POST["fuel_type"];
  $seat_type = $_POST["seat_type"];
  $price = $_POST["price"];
  $vech_num = $_POST["vech_num"];
  $transm_type = $_POST["transm_type"];
  $pincode = $_POST["pincode"];
  $file_path=$_FILES['ins_file'];
  $img_path=$_FILES['car_img'];
  $segment=$_POST['segment'];


$path="";
$path2="";
if(isset($_FILES['ins_file'])){
  $file_name = $_FILES['ins_file']['name'];   
    $targetDir = 'upload_file/';
     $targetFile = $targetDir . basename($file_name); 
     move_uploaded_file($_FILES['ins_file']['tmp_name'], $targetFile);
$path=$targetFile;
}
if(isset($_FILES['car_img'])){
  $file_name = $_FILES['car_img']['name'];   
    $targetDir = 'uploaded_images/';
     $targetFile = $targetDir . basename($file_name); 
     move_uploaded_file($_FILES['car_img']['tmp_name'], $targetFile);
$path2=$targetFile;

}

     $query = "INSERT INTO vehical_host (user_id,full_name,car_brand,car_model,seat_cap,price,city,driven,fuel_type,transm_type,pincode,ins_cer,car_img,segment,vech_num) VALUES('$id','$full_name','$car_brand','$car_model','$seat_type','$price','$city','$driven','$fuel_type','$transm_type','$pincode','$path','$path2','$segment','$vech_num')";


     $consuc= mysqli_query($conn,$query);















header("location:http://localhost/irentacar/Filters.php");
















    // if (!in_array($extension, ['pdf', 'docx'])) {
    //     echo "You file extension must be .pdf or .docx";

    // } elseif ($_FILES['myfile']['size'] > 1000000) { 
    //     echo "File too large!";
    // };
        
  
            
// echo"<pre>". print_r($_POST,true)."</pre>";

 

  

//  $data=mysqli_fetch_assoc($consuc);

//  if(!$consuc){
//     die("not submited :". mysqli_error($conn));
//    }
// else{
//     echo"successfuly submitted";
// }
 
 };




















// $jointable="SELECT login_detail.full_name,login_detail.Id,login_detail.city ,vehical_host.full_name, vehical_host.user_id,vehical_host.city
//    FROM login_detail
//    INNER JOIN vehical_host ON login_detail.Id=vehical_host.user_id;";
//   $getjoindata=mysqli_query($conn,$jointable);

//   $fetchdata=mysqli_fetch_assoc($getjoindata);

  // header("Location:http://localhost/irentacar/Become-a-host.php");
?>




<?php
include 'header.php';
?>

  <!-------------------- End of Header------------------>



  <!-------------------- Pickup Form-------------------->

  <div class="container mx-auto">

    <div class="bg-darkblue rounded-tl-[15px] rounded-tr-[15px] mt-20 w-full flex items-center justify-center p-5">

        <img class="inline-block mr-4 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto" src="images/white-rectangle.png" />

        <h2 class="font-bold font-roboto text-xl text-white uppercase text-center">Host your vehicle</h2>

        <img class="inline-block ml-4 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto" src="images/white-rectangle.png" />

    </div>

    <form action="" enctype="multipart/form-data" method="post" class="border-t-0 border border-borderColor rounded-bl-[15px] rounded-br-[15px] p-16 mb-20">

      <div class="grid grid-cols-2 mx-12 gap-5">

        <div class="w-full">

          <label class="text-headingColor font-roboto font-medium text-base">Car Brand</label><br />

            <select name="car_brand" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor">

                <option>Car Brand</option>

                <option   >Audi</option>

                <option  >BMW</option>

                <option  >Mercedes</option>

                <option  >Ferrari</option>

            </select>

        </div>

        <div class="w-full">

          <label class="text-headingColor font-roboto font-medium text-base">Car Model</label><br />

            <input  name="car_model" type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor" placeholder="Car Model" />

        </div>

        <!-- <div class="w-full">

            <label class="text-headingColor font-roboto font-medium text-base">Car Varient</label><br />

              <input type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor" placeholder="Car Varient" />

          </div> -->

          <div class="w-full">

            <label class="text-headingColor font-roboto font-medium text-base">City</label><br />

              <select  name="city" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor">

                  <option  <?php echo  $_SESSION['users']['city'];?>>Surrey</option>

                  <option <?php echo  $_SESSION['users']['city'];?>>Brampton</option>

                  <option <?php echo $_SESSION['users']['city'];?>>Brockville</option>

                  <option <?php echo $_SESSION['users']['city'];?> >Burlington</option>

              </select>

          </div>
          <div class="w-full">

            <label class="text-headingColor font-roboto font-medium text-base">segment</label><br />

              <select  name="segment" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal border border-borderColor rounded-full py-4 px-2.5 text-placeholderColor">

                  <option >Hatchback</option>

                  <option >SUV</option>

                  <option >MUV</option>

                  <option >Sedan</option>

              </select>

          </div>

         <div class="w-full">

            <label class="text-headingColor font-roboto font-medium text-base">Km Driven</label><br />

              <input name="driven"  type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor" placeholder="15000km" />

          </div>

         <!--   <div class="w-full">

            <label class="text-headingColor font-roboto font-medium text-base">Ownership</label><br />

              <select class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor">

                  <option selected>Ist owner</option>

                  <option>Ist owner</option>

                  <option>Ist owner</option>

                  <option>Ist owner</option>

                  <option>Ist owner</option>

              </select> -->

          

          <div class="w-full">

            <h4 class="text-headingColor font-roboto font-medium text-base w-full mb-3">Fuel Type</h4>

            <label for="type" class="inline-flex mr-4">

              <input name="fuel_type" type="radio" class="checked mr-2 py-4 px-2.5" id="type" value="Diesel"> 

              <div class="text-paragraphColor text-base font-roboto font-normal">Diesel</div>

              </label>

              <label for="petrol" class="inline-flex mr-4" >

              <input  name="fuel_type" type="radio" class="mr-2 py-4 px-2.5" id="petrol" value="Petrol" selected> 

              <div class="text-paragraphColor text-base font-roboto font-normal">Petrol

              </div>

              </label>

              <label for="electric" class="inline-flex">

                <input name="fuel_type" type="radio" class="mr-2 py-4 px-2.5" id="electric" value="Electric"> 

                <div class="text-paragraphColor text-base font-roboto font-normal">Electric</div>

            </label>

          </div>

          <div class="w-full">

            <h4 class="text-headingColor font-roboto font-medium text-base w-full mb-3">Transmission Type</h4>

            <label for="automatic" class="inline-flex mr-4">

              <input name="transm_type" type="radio" class="checked mr-2 py-4 px-2.5" id="automatic" value="Automatic"> 

              <div class="text-paragraphColor text-base font-roboto font-normal">Automatic</div>

              </label>

              <label for="manual" class="inline-flex mr-4">

              <input name="transm_type" type="radio" class="mr-2 py-4 px-2.5" id="manual" value="Manual" selected> 

              <div class="text-paragraphColor text-base font-roboto font-normal">Manual</div>

              </label>

          </div>
          <div class="w-full">

            <label class="text-headingColor font-roboto font-medium text-base">Vehicle number</label><br />

              <input name="vech_num"  type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor" placeholder="pb654545" />

          </div>
        </div>


        <div class="bg-lightColor mt-10 rounded-[15px] p-6 w-full">

<div class="grid-cols-1 gap-4 mb-2">


<label for="dropzone-file" class="mx-auto cursor-pointer flex w-full max-w-lg flex-col items-center rounded-[30px] border border-borderColor bg-white p-6 text-center">

    <p class="mb-5 text-paragraphColor font-base font-medium font-roboto">Upload image of car</p>

    <img src="" class="mb-4">

    <span> </span>



    <input id="img_file" accept=".png,.jpeg" type="file"  name="car_img"  />


</div>



</div>

<div class="bg-lightColor mt-10 rounded-[15px] p-6 w-full">
<div class="grid-cols-2 p-5">

<h4 class="text-headingColor font-roboto font-medium text-base w-full mb-3">Seating Capacity</h4>

<label for="4 seater" class="inline-flex mr-4">

  <input name="seat_type" type="radio" class="checked mr-2 py-4 px-2.5" id="type" value="4 seater"> 

  <div class="text-paragraphColor text-base font-roboto font-normal">4 seater</div>

  </label>

  <label for="5 seater" class="inline-flex mr-4" >

  <input  name="seat_type" type="radio" class="mr-2 py-4 px-2.5" id="petrol" value="5 seater" selected> 

  <div class="text-paragraphColor text-base font-roboto font-normal">5 seater

  </div>

  </label>

  <label for="6 seater" class="inline-flex">

    <input name="seat_type" type="radio" class="mr-2 py-4 px-2.5" id="electric" value="6 seater"> 

    <div class="text-paragraphColor text-base font-roboto font-normal">6 seater</div>

</label>

<div class="grid-cols-2">

            <label class="text-headingColor font-roboto font-medium text-base">Price</label><br />

              <input name="price"  type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full font-roboto font-normal rounded-full py-4 px-2.5 text-placeholderColor" placeholder="$1120" />

          </div>
</div>
</div>

<div class="bg-lightColor mt-10 rounded-[15px] p-6 w-full">

    <div class="grid grid-cols-2 gap-4 mb-2">

    <!-- <input type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full text-base font-roboto font-medium rounded-full py-4 px-3 placeholder:text-paragraphColor" placeholder="Year of registration" /> -->

    <input name="full_name" type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full text-base font-roboto font-medium rounded-full py-4 px-3 placeholder:text-paragraphColor" placeholder="Your Name" value="<?php echo $_SESSION['users']['full_name']; ?>" />

    <input name="pincode" type="text" class="focus:border-darkblue focus:outline-none border borderColor mt-2 w-full text-base font-roboto font-medium rounded-full py-4 px-3 placeholder:text-paragraphColor" placeholder="Pincode" />

    <!-- <input type="text" class="w-full focus:border-darkblue focus:outline-none border borderColor mt-2 w-full text-base font-roboto font-medium rounded-full py-4 px-3 placeholder:text-paragraphColor" placeholder="Chassis number" /> -->



  </div>



</div>

<div class="flex gap-8">

<!-- <main class="flex items-center w-full justify-center mt-10 mb-14">

  <label for="dropzone-file"  class="mx-auto cursor-pointer flex w-full max-w-lg flex-col items-center rounded-[30px] border border-borderColor bg-white p-6 text-center">

    <p class="mb-5 text-paragraphColor font-base font-medium font-roboto">Upload Your Registration Certificate</p>

    <img src="images/upload-icon.svg" class="mb-4" >
    <img src="images/docx.png" class="doc pd_dc"   class="mb-4" style=display:none;>
    <img src="images/pdf.png" class="pdf pd_dc" class="mb-4" style=display:none;>
    <span> </span>


    <input id="dropzone" type="file" name="rc_file"  accept="pdf/*,docx/*" class="hidden" />

    

</main> -->

<main class="flex items-center w-full justify-center mt-10 mb-14">

  <label for="dropzone-file" class="mx-auto cursor-pointer flex w-full max-w-lg flex-col items-center rounded-[30px] border border-borderColor bg-white p-6 text-center">

    <p class="mb-5 text-paragraphColor font-base font-medium font-roboto">Upload Your Insurance Document</p>

    <img src="images/upload-icon.svg" class="mb-4">
    <img src="images/docx.png" class="doc pd_dc"   class="mb-4" style=display:none;> 
    <img src="images/pdf.png" class="pdf pd_dc" class="mb-4" style=display:none;>
    <span> </span>



    <input id="dropzone-file" accept=".docx,.doc,.pdf" type="file"  name="ins_file" class="hidden" />
  
    

</main></div>

<input type="checkbox" class="inline-flex mr-2 mt-3" id="acceptance"><label for="acceptance" class="text-base font-roboto font-normal">I Accept <a href="javascript:void(0)" class="font-roboto font-semibold text-darkblue underline">Terms & Conditions</a></label>



<input type="submit" name="submit" id="sub-btn" class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white py-4 px-20 uppercase" value="Submit" />

</form>

</div>

 <!-------------------- End of Pickup Form---------------------->



 



  

 <!--------------------------- Footer -------------------------->


 <?php
 include 'footer.php';
?>
