<?php
ini_set("display_errors",1);
session_start();
include 'config.php';

$query_to_get="SELECT l.drv_lcen_no, l.mobile_no, l.full_name,l.email_id,v.car_brand,v.car_model,b.avl_from,b.avl_till FROM login_detail l JOIN car_booking b ON l.Id=b.user_id JOIN vehical_host v ON v.Id=b.vech_id";

$exec_to_get= mysqli_query($conn,$query_to_get);
$getdata=mysqli_fetch_assoc($exec_to_get);

?>

<?php
include 'header.php';
?>

  <!-------------------- End of Header------------------------->

  <!-------------------- Profile --------------------------->

  <div class="bg-white py-20">

    <div class="container mx-auto">

        <div class="w-full flex-row flex gap-10 mb-20" id="tabs-id">

            <div class="md:w-2/4 flex flex-col">

        <div class="flex sm:flex-col lg:flex-row bg-darkblue border border-10 border-[#CFE7EB] rounded-[15px] px-8 py-6 sm:space-x-0 md:space-x-0 lg:space-x-5 mb-12">

          <a href="./Profile.php">  <img src="images/profile.png" class="sm:mb-2 sm:w-20 h-20 md:w-20 h-20 mb-0 object-contain mx-auto block lg:w-20 h-20 mb-0 object-contain xl:w-auto h-auto object-contain"></a>

             <div class="flex flex-col justify-center lg:items-start sm:items-center">

             <h1 class="font-roboto font-bold text-xl text-white mb-5"><?php echo $getdata['full_name']?></h1>

             <a href="tel:9872566660" class="font-normal font-roboto text-base text-white mb-2"><?php echo $getdata['mobile_no']?></a>

             <a href="mailto:johndoe@gmail.com" class="font-normal font-roboto text-base text-white"><?php echo $getdata['email_id']?></a>

             </div>

        </div>



        <div class="rounded-full flex flex-col">

          <h3 class="bg-darkblue font-roboto font-bold text-2xl rounded-tl-[15px] rounded-tr-[15px] p-4 text-white text-center">Verified Documents Detail</h3>

          <ul class="flex mb-0 list-none flex-wrap rounded-bl-[15px] rounded-br-[15px] flex-col divide-y divide-borderColor border border-borderColor pt-8 pb-0">

            <li class="flex-auto flex py-4 hover:bg cursor-pointer text-center px-4">

              <a class="flex" onclick="changeAtiveTab(event,'tab-profile')">

                <img src="images/red-cross.png" class="w-10 h-5 object-contain">

                <h4 class="w-10/12 font-roboto font-normal text-paragraphColor text-base text-left">Profile Document </h4> 

               </a>      

              </li>

            <li class="flex-auto  cursor-pointer text-center px-4">

              <a class="flex py-4" onclick="changeAtiveTab(event,'tab-mob-no')">

                <img src="images/green-tick.png" class="w-10 h-5 object-contain">

                <h4 class="font-roboto font-normal text-paragraphColor text-base">Mobile Number</h4>

              </a>

            </li>

            <li class="flex-auto cursor-pointer text-center px-4">

              <a class="flex py-4" onclick="changeAtiveTab(event,'tab-paytm')">

                <img src="images/red-cross.png" class="w-10 h-5 object-contain">

                <h4 class="font-roboto font-normal text-paragraphColor text-base">Paytm Wallet</h4> 

              </a>

            </li>

      

            <li class="flex-auto group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a class="flex py-4" onclick="changeAtiveTab(event,'tab-verification')">

               <img src="images/verify.png" class="w-10 h-5 object-contain group-hover:hidden">

               <img src="images/verify-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">Complete verification of pending documents</h4> 

              </a>

            </li>

            <li class="flex-auto group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a href="./Booking-list.php" class="flex py-4" onclick="changeAtiveTab(event,'tab-hosting')"> 

                <img src="images/hosting-booking-icon.png" class="w-10 h-5 object-contain group-hover:hidden">

                <img src="images/hosting-booking-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">Hosting & Booking Informations</h4> 

              </a>

            </li>

            <li class="flex-auto group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a href="./Rental.php" class="flex py-4" onclick="changeAtiveTab(event,'tab-bookings')">

                <img src="images/bookings.png" class="w-10 h-5 object-contain group-hover:hidden">

                <img src="images/booking-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">My Bookings</h4> 

              </a>

            </li>

            <li class="flex-auto group flex py-4 hover:bg-[#C2E2FF] rounded-bl-[15px] rounded-br-[15px] cursor-pointer text-center px-4">

              <a class="flex p-0" onclick="changeAtiveTab(event,'tab-bank-account')">

                <img src="images/bank-account.png" class="w-10 h-5 object-contain group-hover:hidden">

                <img src="images/bank-account-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">Linked with bank account</h4> 

              </a>

            </li>

          </ul>

        </div>

  

   <!--------------------End of Credit Details--------------------->







   <!------------------------My Account------------------------->

  </div> 

  <div class="tab-content tab-space w-3/4 py-10 rounded-[15px] items-baseline justify-center">

    <div class="hidden" id="tab-profile">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">My Account</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor focus:outline-none font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

    </form>

    </div>   

    <div class="hidden" id="tab-mob-no">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Mobile Number</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor focus:outline-none font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

    </form>

    </div> 

    <div class="hidden" id="tab-paytm">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Paytm Wallet</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor focus:outline-none font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

    </form>

    </div> 

    <div class="hidden" id="tab-verification">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5  flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">verification</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

    </form>

    </div>

    <div class="block" id="tab-hosting">

      <div class="cursor-pointer w-full">

           <a ><img src="images/prev-arrow.png"></a>

      </div>

      <div class="w-full bg-lightColor rounded-[15px] p-8 pb-10 mt-10">

        <div class="w-full pr-5">

       <h4 class="font-roboto font-bold font-base text-headingColor text-center">Time period</h4>

        </div>

       <div class="w-full">

      <div class="flex justify-between mb-2">

      <img src="images/blue-loca-icon.svg">

      <span class="border border-borderColor w-full h-0 my-2"></span>

      <img src="images/red-loca-icon.svg">

  

          </div>

          <div class="flex justify-between">

         <span class="font-roboto font-bold font-base text-darkblue inline-block"><?php echo $getdata['avl_from']?></span>

        <span class="font-roboto font-bold font-base text-darkblue float-right inline-block"><?php echo $getdata['avl_till']?></span> </div>

        <div class="flex justify-between">

        <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

         <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

    

      </div>

  </div>

  

    <form class="border borderColor py-10 px-8 rounded-[15px] mt-10">

        <div class="flex flex-col">

          <div class="w-full flex items-center justify-center mb-5">

            <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

            <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Personal Details</h2>

            <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

        </div>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Name </label>

        <input type="email" value="<?php echo $getdata['full_name']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Contact</label>

        <input type="tel" value="<?php echo $getdata['mobile_no']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

    </div>

    <div class="flex">

      <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Driving license No</label>

      <input type="tel" value="<?php echo $getdata['drv_lcen_no']?>" class="text-paragraphColor font-roboto font-normal text-base w-3/5"> 

  </div>

    </div>

    

    </form>





    <form class="border borderColor py-10 px-8 rounded-[15px] mt-10">

      <div class="flex flex-col">

        <div class="w-full flex items-center justify-center mb-5">

          <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

          <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Rental's Details</h2>

          <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

      </div>

      <div class="flex">

      <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Car Brand Name</label>

      <input type="email" value="<?php echo $getdata['car_brand']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

  </div>

  <div class="flex">

      <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Model</label>

      <input type="tel" value="<?php echo $getdata['car_model']?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-3/5">

  </div>

  <div class="flex">

    <label class="text-paragraphColor font-roboto font-medium text-base w-2/5">Driving license No</label>

    <input type="tel" value="<?php echo $getdata['drv_lcen_no']?>" class="text-paragraphColor font-roboto font-normal text-base w-3/5"> 

</div>

  </div>

  

  </form>



    </div>

    <div class="hidden" id="tab-bookings">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5  flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">My Bookings</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor focus:outline-none font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

    </form>

    </div>

    <div class="hidden" id="tab-bank-account">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-lg text-headingColor uppercase">Linked account</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor focus:outline-none font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

    </form>

    </div>

  </div>

</div> 

</div>

</div>



  <!-------------------- End of My Account ----------------------->







  <!--------------------------- Footer --------------------------->



  <?php
 include 'footer.php';
?>
