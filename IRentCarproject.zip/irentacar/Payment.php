<?php
session_start();
if(isset ($_SESSION['Id'])){

}
else{
  header("location: http://localhost/irentacar/index.php");
  
};

?>


<?php
include 'header.php';
?>
  <!-------------------- End of Header------------------------->

  <!-------------------- Profile --------------------------->

  <div class="bg-white py-20">

    <div class="container mx-auto">

        <h2 class="text-paragraphColor font-roboto font-bold text-3xl mb-8 text-center">Select a Payment method</h2>

        <div class="w-full flex-row flex gap-10 mb-20" id="tabs-id">

            <div class="md:w-2/4 flex flex-col">

   

        <div class="rounded-full flex flex-col">

          <h3 class="bg-darkblue font-roboto font-bold text-2xl rounded-tl-[15px] rounded-tr-[15px] p-4 text-white text-center">Other Payment Options</h3>

          <ul class="flex mb-0 list-none flex-wrap rounded-bl-[15px] rounded-br-[15px] flex-col divide-y divide-borderColor border border-borderColor pb-0">

            <li class="flex-auto flex-col flex py-4 group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

         <a class="flex flex-col" onclick="changeAtiveTab(event,'tab-wallet')">

 <h4 class="font-roboto font-bold text-paragraphColor group-hover:text-darkblue text-base text-left">          

  <img src="images/prime_wallet.svg" class="pr-2 float-left w-8 block group-hover:hidden">  

   <img src="images/prime-wallet-blue.svg" class="pr-2 float-left w-8 hidden group-hover:block">Mobile Wallet </h4>

<p class="text-left pl-8 float-left block w-full font-roboto font-normal text-paragraphColor text-base">Google Pay, Paypal, Cibc</p> 



               </a> 

              </li>

            <li class="flex-auto flex-col group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a class="flex py-4 flex-col" onclick="changeAtiveTab(event,'tab-credit')">



                    <h4 class="group-hover:text-darkblue font-roboto font-bold text-paragraphColor text-base text-left">          

                        <img src="images/credit.svg" class="block group-hover:hidden pr-2 float-left w-8"> Credit / Debit / ATM Card

                        <img src="images/credit-blue-icon.svg" class="pr-2 float-left w-8 hidden group-hover:block">               

                    </h4>

                      <p class="text-left pl-8 float-left block w-full font-roboto font-normal text-paragraphColor text-base">All major card providers are supported </p> 

              </a>

    



            </li>

      

            <li class="flex-auto group group hover:bg-[#C2E2FF] hover:rounded-bl-[15px] hover:rounded-br-[15px] cursor-pointer text-center px-4">

              <a class="flex py-4 flex-col" onclick="changeAtiveTab(event,'tab-net-banking')">



                <h4 class="group-hover:text-darkblue font-roboto font-bold text-paragraphColor text-base text-left">          

                    <img src="images/net-banking.svg" class="block group-hover:hidden pr-2 float-left w-8"> 

                    <img src="images/net-bank-blue.svg" class="pr-2 float-left w-8 hidden group-hover:block">

                    Net Banking </h4>

                  <p class="text-left pl-8 float-left block w-full font-roboto font-normal text-paragraphColor text-base">All major wallets are supported </p> 

              </a>

            </li>

          </ul>

        </div>

  

   <!--------------------End of Credit Details--------------------->







   <!------------------------My Account------------------------->

  </div> 

  <div class="tab-content tab-space w-3/4 border border-borderColor px-6 py-10 rounded-[15px] items-baseline justify-center">

    <div class="block" id="tab-wallet">

      <div class="w-full flex gap-5  justify-start">

        <div class="w-2/4">

        <h3 class="font-bold font-roboto text-xl text-headingColor">Select a UPI App</h3>

        <p class="font-bold font-roboto font-normal text-base text-[#A6A6A6]">Amount: $220.0</p>

  <ul class="flex mb-0 list-none flex-wrap flex-col divide-y divide-borderColor pb-0">

  <li class="flex-auto flex-col flex py-5 group cursor-pointer text-center pr-4">

             <a class="flex" onclick="changeAtiveTab(event,'tab-upi')">

                <img src="images/paypal.svg" class="pr-5">

     <h4 class="font-roboto font-bold text-paragraphColor text-xl text-left">          

       Paypal</h4>

    </a> 

 </li>

 <li class="flex-auto flex-col flex py-5 group cursor-pointer text-center pr-4">

    <a class="flex" onclick="changeAtiveTab(event,'tab-upi')">

        <img src="images/google-wallet.svg" class="pr-5"> 

<h4 class="font-roboto font-bold text-paragraphColor text-xl text-left">          

Google Wallet</h4>

</a> 

</li>

<li class="flex-auto flex-col flex py-5 group cursor-pointer text-center pr-4">

    <a class="flex" onclick="changeAtiveTab(event,'tab-upi')">

 <img src="images/cibc.svg" class="pr-5"> 

<h4 class="font-roboto font-bold text-paragraphColor text-xl text-left">          

  Cibc</h4>

</a> 

</li>

 </ul>

    </div>



    <div class="w-2/4 bg-lightColor pt-10 rounded-tr-[15px] rounded-br-[15px]">

        <h3 class="font-bold font-roboto mb-3 text-xl text-headingColor text-center">Select a UPI App</h3>

        <img src="images/scan-code.jpg" class="m-auto">

        </div>

        

</div>



    </div>   

    <div class="hidden" id="tab-credit">

      <div class="w-full">
        <h3 class="font-roboto font-bold text-paragraphColor text-base text-left mb-4">Cardholder’s name</h3>
          <input class="border border-borderColor p-4 rounded-[15px] focus:outline-none focus:border-darkblue w-full mb-4" type="number" name="cardnumber" placeholder="Cardholder’s name">
          <h3 class="font-roboto font-bold text-paragraphColor text-base text-left mb-4">Card Number</h3>
          <input class="border border-borderColor p-4 rounded-[15px] focus:outline-none focus:border-darkblue w-full mb-4" type="number" name="cardnumber" placeholder="Card number">
    </div>   
    <div class="flex gap-5">
    <input class="border border-borderColor p-4 rounded-[15px] focus:outline-none focus:border-darkblue w-full mb-2" type="number" name="cardnumber" placeholder="Expiry Date">
    <input class="border border-borderColor p-4 rounded-[15px] focus:outline-none focus:border-darkblue w-full mb-2" type="number" name="cardnumber" placeholder="CVV">
  </div> 
  <div class="w-full mt-5">
  <input class="border border-borderColor bg-darkblue text-white mr-5 cursor-pointer p-4 rounded-[15px] focus:outline-none focus:border-darkblue w-full mb-2" type="submit" placeholder="CVV">
</div> 
</div> 

    <div class="hidden" id="tab-net-banking">
  </div>

</div> 

</div>
</div>
</div>


 



  <!-------------------- End of My Account ----------------------->







  <!--------------------------- Footer --------------------------->
 <?php
 include 'footer.php';
?>

<!---------------------------End of Footer ---------------------------->


