 <?php 
ini_set("display_errors",1);
session_start();


if(!isset($_SESSION['users']['id'])){
  header("location: http://localhost/irentacar/index.php");
}




include 'config.php';
$id=$_SESSION['users']['id'];
$fetch= "SELECT * FROM login_detail where Id = '$id' ";
$data= mysqli_query($conn,$fetch);

 $fetchdata=mysqli_fetch_assoc($data);
// echo $fetchdata['Id'];
// echo $fetchdata['email_id'];

if (isset($_POST["update"])){
  $email = $_POST["email"];
  $city = $_POST["city"];
  $mobile = $_POST["mobile"];
  $gender = $_POST["gender"];
  $fullname= $_POST["fullname"];

  // $file= $_FILES["file"];

  // if(isset($_FILES["file"])){
  //   $image_name = $_FILES['file']['name'];   
  //   $targetDir = 'uploaded_images/';
  //    $targetFile = $targetDir . basename($image_name); 
  //    move_uploaded_file($_FILES['file']['tmp_name'], $targetFile); 
  //}
    // echo"<pre>";
    // print_r($_FILES["file"]);
    // echo "</pre>";
 



  
  $query =  "UPDATE login_detail SET  full_name='$fullname',gender='$gender', city='$city',email_id='$email', mobile_no='$mobile'  WHERE Id=$id";

 $consuc= mysqli_query($conn,$query);

header("Location:http://localhost/irentacar/Profile.php");






  }
?>




<?php
include 'header.php';
?>


<!-------------------- End of Header------------------------->

  <!-------------------- Profile --------------------------->
  
  <div class="bg-white py-20">

    <div class="container mx-auto">

    
        <div class="w-full flex-row flex gap-10 mb-20" id="tabs-id">

            <div class="md:w-2/4 flex flex-col">

        <div class="flex sm:flex-col lg:flex-row bg-darkblue border border-10 border-[#CFE7EB] rounded-[15px] px-8 py-6 sm:space-x-0 md:space-x-0 lg:space-x-5 mb-12">

       
          <input  type="file" id="file" name="file"/>
             <a  id="anchor"  href="javascript:void(0)">
              <img id="show_img" src="<?php echo $fetchdata['file']=== file_exists($fetchdata['file']) || $fetchdata['file'] !="" ? $fetchdata['file'] : "images/profile.png";?>"  class="sm:mb-2 sm:w-20 h-20 md:w-20 h-20 mb-0 object-contain mx-auto block lg:w-20 h-20 mb-0 object-contain xl:w-auto h-auto object-contain rounded-full"></a>
           
             <div class="flex flex-col justify-center lg:items-start sm:items-center">

             <h1 class="font-roboto font-bold text-xl text-white mb-5"><?php echo $fetchdata['full_name']; ?></h1>

             <a href="tel:9872566660" class="font-normal font-roboto text-base text-white mb-2"><?php echo $fetchdata['mobile_no']; ?></a>

             <a href="mailto:johndoe@gmail.com" class="font-normal font-roboto text-base text-white"><?php echo $fetchdata['email_id']; ?></a>

             </div>

        </div>



        <div class="rounded-full flex flex-col">

          <h3 class="bg-darkblue font-roboto font-bold text-2xl rounded-tl-[15px] rounded-tr-[15px] p-4 text-white text-center">Verified Documents Detail</h3>

          <ul class="flex mb-0 list-none flex-wrap rounded-bl-[15px] rounded-br-[15px] flex-col divide-y divide-borderColor border border-borderColor pt-8 pb-0">

            <li class="flex-auto flex py-4 hover:bg cursor-pointer text-center px-4">

              <a class="flex" onclick="changeAtiveTab(event,'tab-profile')">

                <img src="images/red-cross.png" class="w-10 h-5 object-contain">

                <h4 class="w-10/12 font-roboto font-normal text-paragraphColor text-base text-left">Profile Document </h4> 

               </a>      

              </li>

            <li class="flex-auto  cursor-pointer text-center px-4">

              <a class="flex py-4" onclick="changeAtiveTab(event,'tab-mob-no')">

                <img src="images/green-tick.png" class="w-10 h-5 object-contain">

                <h4 class="font-roboto font-normal text-paragraphColor text-base">Mobile Number</h4>

              </a>

            </li>


          <!--  <li class="flex-auto cursor-pointer text-center px-4">

              <a class="flex py-4" onclick="changeAtiveTab(event,'tab-paytm')">

                <img src="images/red-cross.png" class="w-10 h-5 object-contain">

                <h4 class="font-roboto font-normal text-paragraphColor text-base">Paytm Wallet</h4> 

              </a>

            </li>

      

            <li class="flex-auto group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a class="flex py-4" onclick="changeAtiveTab(event,'tab-verification')">

               <img src="images/verify.png" class="w-10 h-5 object-contain group-hover:hidden">

               <img src="images/verify-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">Complete verification of pending documents</h4> 

              </a>

            </li> -->

            <li class="flex-auto group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a  class="flex py-4" onclick="changeAtiveTab(event,'tab-hosting')"> 

                <img src="images/hosting-booking-icon.png" class="w-10 h-5 object-contain group-hover:hidden">

                <img src="images/hosting-booking-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">Hosting & Booking Informations</h4> 

              </a>

            </li>
<!-- 
            <li class="flex-auto group hover:bg-[#C2E2FF] cursor-pointer text-center px-4">

              <a href="./Rental.html" class="flex py-4" onclick="changeAtiveTab(event,'tab-bookings')">

                <img src="images/bookings.png" class="w-10 h-5 object-contain group-hover:hidden">

                <img src="images/booking-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">My Bookings</h4> 

              </a>

            </li>

            <li class="flex-auto group flex py-4 hover:bg-[#C2E2FF] rounded-bl-[15px] rounded-br-[15px] cursor-pointer text-center px-4">

              <a class="flex p-0" onclick="changeAtiveTab(event,'tab-bank-account')">

                <img src="images/bank-account.png" class="w-10 h-5 object-contain group-hover:hidden">

                <img src="images/bank-account-blue-icon.png" class="w-10 h-5 object-contain hidden group-hover:block">

                <h4 class="font-roboto group-hover:text-darkblue group-hover:font-bold font-normal text-paragraphColor text-base">Linked with bank account</h4> 

              </a>

            </li> -->

          </ul>

        </div>

  

   <!--------------------End of Credit Details--------------------->







   <!------------------------My Account------------------------->

  </div> 



  <div class="tab-content tab-space w-3/4 border border-borderColor px-6 py-10 rounded-[15px] items-baseline justify-center">

    <div class="block" id="tab-profile">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">My Account</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    <form action="" enctype="multipart/form-data" method="post">

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" name="email" value="<?php echo $fetchdata['email_id']; ?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel"  name="mobile" value="<?php echo $fetchdata['mobile_no']; ?>" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text"  name="fullname" value="<?php echo $fetchdata['full_name']; ?>" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select   name="gender"  class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option <?php echo $fetchdata['gender'] == "Male" ? 'selected': '';  ?> >Male</option>

            <option <?php echo  $fetchdata['gender'] == "Female" ? 'selected': '' ;?>  >Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select  name="city"  class="text-paragraphColor focus:outline-none font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option <?php echo  $fetchdata['city'] == "colmbia" ? 'selected': '' ;?> >colmbia</option> 

                <option <?php echo  $fetchdata['city'] == "North Vancouver" ? 'selected': '' ;?>  >North Vancouver</option>

                <option <?php echo  $fetchdata['city'] == "Burnaby" ? 'selected': '' ;?> >Burnaby</option>

                <option <?php echo  $fetchdata['city'] == "Victoria" ? 'selected': '' ;?> >Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit" name="update"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

        </form>

</div>

    </div>   
   
</div> 

</div> 

    <div class="hidden" id="tab-mob-no">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Mobile Number</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

  <form>

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor font-roboto focus:outline-none font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

        </form>

    </div> 
<!-- 
   <div class="hidden" id="tab-paytm">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">Paytm Wallet</h2>

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

    </div>

  



        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor font-roboto focus:outline-none font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

   

    </div> 

    <div class="hidden" id="tab-verification">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5  flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">verification</h2>

        <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

    </div>

    

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor font-roboto focus:outline-none font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />

    

   

    </div>  -->

    <div class="hidden" id="tab-hosting">

      <div class="grid grid-cols-2 gap-3 items-center justify-center">

        <a  class="w-full cursor-pointer">

          <button class="font-roboto text-xl bg-darkblue w-full rounded-full text-white font-bold py-5 px-10 uppercase">Bookings</button></a>

        <a href="./Published-List.html" class="w-full cursor-pointer">

          <button class="font-roboto text-xl bg-headingColor w-full rounded-full text-white font-bold py-5 px-10 uppercase">Published Car List</button></a>

    </div>

    <div class="w-full items-center justify-center bg-lightColor p-5 rounded-[15px] pt-8 pb-10 mt-10">

      <div class="w-full flex justify-between">

        <h4 class="font-roboto font-medium font-lg text-paragraphColor inline-block">Number of bookings</h4>

          <h4 class="font-roboto font-medium font-lg text-paragraphColor inline-block">04</h4>

      </div>



      <div class="border border-[#DDDDDD] w-full h-0 my-2"></div>

    </div> 



    <div class="w-full bg-lightColor rounded-[15px] pt-8 pb-10 mt-10">

      <div class="w-full pr-5">

        <ul class="flex justify-between">

    <li class="font-roboto font-semibold font-lg uppercase text-white bg-[#34A853] py-4 pl-8 pr-12 rounded-tr-[15px] rounded-br-[15px] list-disc list-inside">Live</li>

     <li><a href="javascript:void(0)" class="cursor-pointer float-right"><button class="font-roboto text-lg bg-[#C2E2FF] rounded-full text-paragraphColor font-medium py-3 px-10">ID 123456</button></a></li>

    </ul> </div>

     <div class="w-full pr-5">

        <div class="w-full pt-4 flex pl-5 gap-10">

        <div class="w-2/5">

       <img src="images/small-car.png" class="rounded-[15px] w-full">

      <h4 class="font-roboto font-normal font-base text-paragraphColor mt-2 text-center w-1/ mx-auto">Merceded benz M Class</h4>

      </div>

       <div class="w-3/5">

        <div class="flex justify-between mb-2">

    <img src="images/blue-loca-icon.svg">

    <span class="border border-borderColor w-full h-0 my-2"></span>

    <img src="images/red-loca-icon.svg">



        </div>

        <div class="flex justify-between">

       <span class="font-roboto font-bold font-base text-darkblue inline-block">Mon 6 Feb 2023</span>

      <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">Wed 8 Feb 2023</span> </div>

      <div class="flex justify-between">

      <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

       <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

    </div>   </div>

    <div class="w-full flex justify-end items-center">

        <span class="font-roboto text-base rounded-full text-[#A6A6A6] font-normal mr-4">$552</span>

    <a href="./Booking-List-Previous.html" class="cursor-pointer block"><button class="font-roboto text-base bg-darkblue rounded-full text-white font-semibold py-4 px-14 uppercase">Preview</button></a>

    </div>

  

    </div>

</div>



<div class="w-full bg-lightColor rounded-[15px] pt-8 pb-10 mt-10">

  <div class="w-full pr-5">

 <span class="font-roboto font-semibold font-lg uppercase text-white bg-headingColor py-4 pl-8 pr-12 rounded-tr-[15px] rounded-br-[15px]">Upcoming</span>

 <a href="javascript:void(0)" class="cursor-pointer float-right"><button class="font-roboto text-lg bg-[#C2E2FF] rounded-full text-paragraphColor font-medium py-3 px-10">ID 123456</button></a>

 </div>

 <div class="w-full pr-5">

    <div class="w-full pt-4 flex pl-5 gap-10">

    <div class="w-2/5">

   <img src="images/small-car.png" class="rounded-[15px] w-full">

  <h4 class="font-roboto font-normal font-base text-paragraphColor mt-2 text-center w-1/ mx-auto">Merceded benz M Class</h4>

  </div>

   <div class="w-3/5">

    <div class="flex justify-between mb-2">

<img src="images/blue-loca-icon.svg">

<span class="border border-borderColor w-full h-0 my-2"></span>

<img src="images/red-loca-icon.svg">



    </div>

    <div class="flex justify-between">

   <span class="font-roboto font-bold font-base text-darkblue inline-block">Mon 6 Feb 2023</span>

  <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">Wed 8 Feb 2023</span> </div>

  <div class="flex justify-between">

  <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

   <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

</div>   </div>

<div class="w-full flex justify-end items-center">

  <span class="font-roboto text-base rounded-full text-[#A6A6A6] font-normal mr-4">$552</span>

  <a href="javascript:void(0)" class="cursor-pointer float-right"><button class="font-roboto text-lg bg-[#C2E2FF] rounded-full text-black uppercase font-semibold py-3 px-12 mr-2">Cancel</button></a>

<a href="javascript:void(0)" class="cursor-pointer block"><button class="font-roboto text-base bg-darkblue rounded-full text-white font-semibold py-4 px-14 uppercase">Preview</button></a>

</div>



</div>

</div>





<div class="w-full bg-lightColor rounded-[15px] pt-8 pb-10 mt-10">

  <div class="w-full pr-5">

 <span class="font-roboto font-semibold font-lg uppercase text-white bg-headingColor py-4 pl-8 pr-12 rounded-tr-[15px] rounded-br-[15px]">Completed</span>

 <a href="javascript:void(0)" class="cursor-pointer float-right"><button class="font-roboto text-lg bg-[#C2E2FF] rounded-full text-paragraphColor font-medium py-3 px-10">ID 123456</button></a>

 </div>

 <div class="w-full pr-5">

    <div class="w-full pt-4 flex pl-5 gap-10">

    <div class="w-2/5">

   <img src="images/small-car.png" class="rounded-[15px] w-full">

  <h4 class="font-roboto font-normal font-base text-paragraphColor mt-2 text-center w-1/ mx-auto">Merceded benz M Class</h4>

  </div>

   <div class="w-3/5">

    <div class="flex justify-between mb-2">

<img src="images/blue-loca-icon.svg">

<span class="border border-borderColor w-full h-0 my-2"></span>

<img src="images/red-loca-icon.svg">



    </div>

    <div class="flex justify-between">

   <span class="font-roboto font-bold font-base text-darkblue inline-block">Mon 6 Feb 2023</span>

  <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">Wed 8 Feb 2023</span> </div>

  <div class="flex justify-between">

  <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

   <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

</div>   </div>

<div class="w-full flex justify-end items-center">

  <span class="font-roboto text-base rounded-full text-[#A6A6A6] font-normal mr-4">$552</span>

<a href="javascript:void(0)" class="cursor-pointer block"><button class="font-roboto text-base bg-darkblue rounded-full text-white font-semibold py-4 px-14 uppercase">Preview</button></a>

</div>



</div>

</div>





 </div>

   <!-- <div class="hidden" id="tab-bookings">

      <div class="w-full items-center justify-center bg-lightColor rounded-[15px] pt-8 pb-10">

        <div class="w-full">

       <span class="font-roboto font-semibold font-lg uppercase text-white bg-headingColor py-4 pl-8 pr-12 rounded-tr-[15px] rounded-br-[15px]">Pending</span>

       </div>

       <div class="w-full pr-10">

          <div class="w-full pt-10 flex pl-5">

          <div class="w-2/5">

         <img src="images/small-car.png" class="rounded-[15px] w-44"></div>

         <div class="w-3/5">

          <div class="flex justify-between mb-2">

      <img src="images/blue-loca-icon.svg">

      <span class="border border-borderColor w-full h-0 my-2"></span>

      <img src="images/red-loca-icon.svg">



          </div>

          <div class="flex justify-between">

         <span class="font-roboto font-bold font-base text-darkblue inline-block">Mon 6 Feb 2023</span>

        <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">Wed 8 Feb 2023</span> </div>

        <div class="flex justify-between">

        <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

         <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

      </div>   </div>

      <div class="w-full flex justify-end pr-2">

      <a href="javascript:void(0)" class="cursor-pointer block"><button class="font-roboto text-base bg-[#C2E2FF] rounded-full text-headingColor font-semibold py-4 px-16 mr-2">$552</button></a>

      <a href="javascript:void(0)" class="cursor-pointer block"><button class="font-roboto text-base bg-darkblue rounded-full text-white font-semibold py-4 px-14 uppercase mr-2">cancel</button></a>

      </div>

    

      </div>

  </div>





  <div class="w-full items-center justify-center bg-lightColor rounded-[15px] pt-8 pb-10 mt-8">

      <div class="w-full">

     <span class="font-roboto font-semibold font-lg uppercase text-white bg-headingColor py-4 pl-8 pr-12 rounded-tr-[15px] rounded-br-[15px]">completed</span>

     </div>

     <div class="w-full pr-10">

        <div class="w-full pt-10 flex pl-5">

        <div class="w-2/5">

       <img src="images/small-car.png" class="rounded-[15px] w-44"></div>

       <div class="w-3/5">

        <div class="flex justify-between mb-2">

    <img src="images/blue-loca-icon.svg">

    <span class="border border-borderColor w-full h-0 my-2"></span>

    <img src="images/red-loca-icon.svg">



        </div>

        <div class="flex justify-between">

       <span class="font-roboto font-bold font-base text-darkblue inline-block">Mon 6 Feb 2023</span>

      <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">Wed 8 Feb 2023</span> </div>

      <div class="flex justify-between">

      <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

       <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

    </div>   

  

  </div>

    <div class="w-full flex justify-center">

    <a href="javascript:void(0)" class="cursor-pointer block"><button class="font-roboto text-base bg-[#C2E2FF] rounded-full text-headingColor font-semibold py-4 px-16">$552</button></a>

    </div>

  

    </div>

</div>







<div class="w-full items-center justify-center bg-lightColor rounded-[15px] pt-8 pb-10 mt-8">

  <div class="w-full">

 <span class="font-roboto font-semibold font-lg uppercase text-white bg-headingColor py-4 pl-8 pr-12 rounded-tr-[15px] rounded-br-[15px]">completed</span>

 </div>

 <div class="w-full pr-10">

    <div class="w-full pt-10 flex pl-5">

    <div class="w-2/5">

   <img src="images/small-car.png" class="rounded-[15px] w-44"></div>

   <div class="w-3/5">

    <div class="flex justify-between mb-2">

<img src="images/blue-loca-icon.svg">

<span class="border border-borderColor w-full h-0 my-2"></span>

<img src="images/red-loca-icon.svg">



    </div>

    <div class="flex justify-between">

   <span class="font-roboto font-bold font-base text-darkblue inline-block">Mon 6 Feb 2023</span>

  <span class="font-roboto font-bold font-base text-darkblue float-right inline-block">Wed 8 Feb 2023</span> </div>

  <div class="flex justify-between">

  <span class="font-roboto font-normal font-base text-paragraphColor inline-block opacity-50">10:30am</span>

   <span class="font-roboto font-normal font-base text-paragraphColor float-right inline-block opacity-50">10:30pm</span></div>

</div>   </div>

<div class="w-full flex justify-center">

<a href="javascript:void(0)" class="cursor-pointer block"><button class="font-roboto text-base bg-[#C2E2FF] rounded-full text-headingColor font-semibold py-4 px-16">$552</button></a>

</div>



</div>

</div>

</div>

    <div class="hidden" id="tab-bank-account">

      <div class="w-full flex items-center justify-center">

        <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

        <h2 class="font-bold font-roboto text-lg text-headingColor uppercase">Linked account</h2>

        <img class="inline-block mlr-1.5 flex-1" src="images/line.png" />

    </div>

   

        <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Account Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Email: </label>

        <input type="email" value="johndoe@gmail.com" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Mobile:</label>

        <input type="tel" value="9872***017" class="text-paragraphColor font-roboto font-normal text-base w-4/5"> 

    </div>

    </div>

    

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Personal Details</h3>

        <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Name: </label>

        <input type="text" value="John" class="text-paragraphColor font-roboto font-normal text-base mb-4 w-4/5"><br>

    </div>

    <div class="flex">

        <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">Gender:</label>

        <select class="text-paragraphColor font-roboto font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2"> 

            <option>Male</option>

            <option>Female</option>

      </select>  

    </div>

    </div>

    

    <div class="mt-10 flex flex-col">

        <h3 class="font-medium font-roboto text-lg text-paragraphColor border-b-2 border-[#DDDDDD] pb-1 mb-5">Location Details</h3>

        <label class="text-paragraphColor font-roboto font-medium text-base block">Please share your current city for optimized experience </label><br>

        <div class="flex">

            <label class="text-paragraphColor font-roboto font-medium text-base w-1/5">City:  </label>

            <select class="text-paragraphColor font-roboto focus:outline-none font-normal text-base border border-borderColor rounded-[30px] pl-2 pr-12 py-2">

                <option></option> 

                <option>North Vancouver</option>

                <option>Burnaby</option>

                <option>Victoria</option>

            </select>     

       

    </div>

    </div>

        <input type="submit"

        class="cursor-pointer mt-12 block font-roboto text-base bg-darkblue rounded-full text-white font-bold py-4 px-20 uppercase"

        value="Update" />
  -->
    


    

    </div>

  </div>
 
</div> 

</div>
</div>


  <!-------------------- End of My Account ----------------------->







  <?php
include 'footer.php';

?>

<?php  if( $fetch_mybookdata['avl_from']>now()){
echo "PENDING";
}
elseif ($fetch_mybookdata['avl_from']>=now() || $fetch_mybookdata['avl_till']<=now()) {
  echo "LIVE";
}
elseif ($fetch_mybookdata['avl_till']<=now()) {
  echo "completed";
}
       else{
        echo "not found";
       }?>