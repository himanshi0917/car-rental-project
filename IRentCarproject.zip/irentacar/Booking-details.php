<?php
ini_set("display_errors",1);
session_start();
if(!isset($_SESSION['users']['id'])){
  header("location: http://localhost/irentacar/filter.php");
}
include 'config.php';

$id=$_GET['vech_id'];

$que_booking="SELECT * FROM vehical_host WHERE Id=$id";
$fet_booking=mysqli_query($conn,$que_booking);
$data_booking=mysqli_fetch_assoc($fet_booking);



$GetUserId=$_SESSION['users']['id'];
if(isset($_POST['GetVechId'])){
  $GetVechId=$_POST['GetVechId'];
  $Datetime=$_POST['datetimes'];
  $datetime= explode("-",$Datetime);
  $DateFrom=str_replace("/","-",trim($datetime[0]));
  $DateTill=str_replace("/","-",trim($datetime[1]));

  // $d_from=DateTime::createFromFormat('F j,Y h:i A',$DateFrom );
// $convertfromdate=$DateFrom->format('Y-m-d H:i:s');
// $d_till=DateTime::createFromFormat('F j,Y h:i A', $DateTill );
// $converttilldate= $DateTill->format('Y-m-d H:i:s');

echo $DateFrom ."" .$DateTill;
  $insert_In_Booking="INSERT INTO car_booking (vech_id,user_id,avl_from,avl_till) VALUES ('$GetVechId','$GetUserId', '$DateFrom','$DateTill')";

  $execu_query= mysqli_query($conn,$insert_In_Booking);


  if(!$execu_query){ 
    die("failed to connect :". mysqli_connect_error());
 }
else{
 
 header("Location: http://localhost/irentacar/profile.php");
}
 
}





?>
<?php
include 'header.php';
?>

  <!-------------------- End of Header------------------------->



  <!-------------------- Profile --------------------------->

  <div class="bg-white py-20">

    <div class="container mx-auto">

        <div class="w-full flex-row flex gap-11" id="tabs-id">

            <div class="md:w-3/5 flex flex-col">

                <div class="w-full flex flex-1 items-center justify-center mb-8">

                    <img class="inline-block mr-1.5 flex-1" src="images/line.png" />

                    <h2 class="font-bold font-roboto text-lg text-headingColor uppercase text-center">Booking Details</h2>

                    <img class="inline-block ml-1.5 flex-1" src="images/line.png" />

                </div>

        <div class="flex flex-col justify-center bg-lightColor border border-borderColor rounded-[15px] px-8 py-10 space-x-5 mb-9 mx-16">
        <form action="" method="post" id="form-id">
             <div class="grid-cols-1 place-items-center mb-10">

             <input type="text" name="datetimes" id="date-pick" class="focus:outline-none focus:border-darkblue border mt-2 w-full font-roboto font-normal border-borderColor rounded-full py-4 px-2.5 text-paragraphColor bg-[url('images/calender-icon.svg')] bg-no-repeat bg-[98%_center]" />

             </div>
<input type="hidden" name="GetVechId" value="<?php echo $data_booking['Id']?>">


             <div class="block">

                <p class="font-medium font-roboto font-lg text-paragraphColor text-center"><?php echo $data_booking['city']."   ". $data_booking['pincode']?></p>

               </div>
</form>
             </div>

     <div id="tab-hosting">        

         <div class="w-full">

             <img src="<?php echo $data_booking['car_img']?>" class="w-full">

         </div>

         <div class="mt-6 flex gap-3 justify-between items-center">

          <div class="flex-1">

           <img src="images/seater.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $data_booking['seat_cap']?></label>

         </div>

         <div class="flex-1">

           <img src="images/fuel-pump-diesel.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $data_booking['fuel_type']?></label>

         </div>

         <div class="flex-1">

           <img src="images/automatic-icon.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $data_booking['transm_type']?></label>

         </div>

         <div class="flex-1">

           <img src="images/suv-car-icon.png" class="inline-block mr-2 align-middle"> <label class="font-base font-roboto text-base text-paragraphColor text-center"><?php echo $data_booking['segment']?></label>

         </div>

    

        </div>

        <div class="w-full flex items-center mb-5 mt-14">

             <img class="inline-block mr-1.5 flex-1" src="images/short-lines.png" />

             <h2 class="font-bold font-roboto text-xl text-headingColor uppercase text-center">IMPORTANT POINTS TO REMEMBER</h2>

             <img class="inline-block ml-1.5 flex-1" src="images/short-lines.png" />

         </div>

         <div class="w-full flex flex-col mb-5 mt-14"> 

          <div class="flex mb-8">

            <div class="block">

          <img class="mr-5 w-7" src="images/drivers-license.png" />



        </div>

          <h3 class="font-normal font-roboto text-base text-paragraphColor">Driving License Mandatory</h3>

        </div>

        <div class="flex mb-8">

        <div class="block">

          <img class="mr-12" src="images/fuel-pump-diesel.png" />

          </div>

          <div class="flex flex-col">

          <h3 class="font-normal font-roboto text-base text-paragraphColor">Fare & Fuel Policy</h3>

          <p class="font-normal font-roboto text-base text-paragraphColor mt-2">Praesent quis risus maximus arcu luctus egestas. Aliquam rhoncus metus eu dui 

            aliquet, ut imperdiet metus fringilla.</p>

            <a href="javascript:void(0)" class="font-semibold font-roboto text-base text-darkblue underline mt-2">See Details</a>

        </div>

        </div>

          <div class="flex mb-8">

            <div class="block">

          <img class="mr-12" src="images/cancel-policy.png" />

        </div>

        <div class="flex flex-col">

          <h3 class="font-normal font-roboto text-base text-paragraphColor">Cancellation Policy</h3>

          <p class="font-normal font-roboto text-base text-paragraphColor mt-2">Praesent quis risus maximus arcu luctus egestas. Aliquam rhoncus metus eu dui 

            aliquet, ut imperdiet metus fringilla.</p>

            <a href="javascript:void(0)" class="font-semibold font-roboto text-base text-darkblue underline mt-2">See Details</a>



          </div>

        </div>

          <div class="flex mb-8">

            <div class="block">

          <img class="mr-12" src="images/agreement.png" />

        </div>

       <div class="flex flex-col">

          <h3 class="font-normal font-roboto text-base text-paragraphColor">Agreement Policy</h3>

          <p class="font-normal font-roboto text-base text-paragraphColor mt-2">Praesent quis risus maximus arcu luctus egestas. Aliquam rhoncus metus eu dui 

            aliquet, ut imperdiet metus fringilla.</p>

            <a href="javascript:void(0)" class="font-semibold font-roboto text-base text-darkblue underline mt-2">See Details</a>



        </div>

        </div>

        </div>

         </div>

            </div>



  

   <!--------------------End of Credit Details--------------------->







   <!------------------------My Account------------------------->

  

  <div class="h-full w-2/5 border border-borderColor px-6 py-10 rounded-[15px] items-baseline justify-center">

    <div class="block">

      <div class="w-full flex items-center justify-center mb-5">

        <img class="inline-block mr-4 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto" src="images/short-lines.png" />

        <h2 class="font-bold font-roboto text-xl text-headingColor uppercase">FARE DETAILS</h2>

        <img class="inline-block ml-4 sm:w-10 md:w-20  xl:w-auto 2xl:w-auto" src="images/short-lines.png" />

    </div>

    <table class="table-auto w-full">

        <!-- <thead>

          <tr>

            <th>Song</th>

            <th>Artist</th>

          </tr>

        </thead> -->

        <tbody>

          <tr>

            <td class="py-3 font-roboto font-base font-normal text-paragraphColor">Base fare</td>

            <td class="py-3 font-roboto font-base font-semibold text-paragraphColor"><?php echo $data_booking['price']?></td>

          </tr>

          <tr>

            <td class="py-3 font-roboto font-base font-normal text-paragraphColor">Doorstep delivery & pickup</td>

            <td class="py-3 font-roboto font-base font-semibold text-paragraphColor">$110</td>

          </tr>

          <tr>

            <td class="py-3 font-roboto font-base font-normal text-paragraphColor">Insurance & GST</td>

            <td class="py-3 font-roboto font-base font-semibold text-paragraphColor">Included</td>

          </tr>

          <tr>

            <td class="py-3 font-roboto font-base font-normal text-paragraphColor">Refundable security deposit</td>

            <td class="py-3 font-roboto font-base font-semibold text-paragraphColor">$220</td>

          </tr>

          <tr class="border-y-2 border-[#DDDDDD]">

            <td class="py-3 my-1 font-roboto font-base font-semibold text-paragraphColor">Total</td>

            <td class="py-3 my-1 font-roboto font-base font-semibold text-paragraphColor">$1450</td>

          </tr>


          <tr>

            <td class="py-3 font-roboto font-base font-normal text-paragraphColor">Tolls, Parking & Inter-state taxes</td>

            <td class="py-3 font-roboto font-base font-semibold text-paragraphColor">To be paid by you</td>

          </tr>



        </tbody>

      </table>



      <input type="checkbox" class="inline-flex mr-2 mt-3" id="acceptance">

      <label for="acceptance" class="text-base font-roboto font-normal">I accept all the terms & conditions</label>

    <input type="button"  name="proceed" id="sub-btn" onclick="$('#form-id').submit()" class="text-center w-full cursor-pointer mt-4 block font-roboto text-base bg-darkblue rounded-full font-bold text-white py-4 px-20 uppercase" value="Proceed" />



  </div>

</div> 

</div>

</div></div>





  <!-------------------- End of My Account ----------------------->







  <!--------------------------- Footer --------------------------->



  <?php
 include 'footer.php';
?>
